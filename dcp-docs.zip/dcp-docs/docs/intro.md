---
sidebar_position: 1
---

# Overview

Inrevo IOT system can collect data from various industrial sources including CNC, PLC, DCS, smart instruments, and robots, process the data according to custom requirements, and supports various types of data applications.

Inrevo IOT system supports two different usage scenarios: standalone mode and remote monitoring mode. In standalone mode, there is a single data node (aka **Node**), whereas in remote monitoring mode, there are multiple data nodes and a monitoring node (aka **Monitor**).

![standalone](.\img\standalone.png)

<center>
Standalone Mode
</center>



![monitoring](.\img\monitoring.png)

<center>
Remote Monitoring Mode
</center>

In standalone mode, the system supports local data collection and navigation. 

In remote monitoring mode, you can remotely manage and control each data node to collect data, and the data nodes will sync data to the monitor node side for application access.



## Features

With Inrevo IOT system you can do the following:

- Collect data from various industrial devices.
- Process the collected data with custom calculation formula.
- Support storing real-time and historical data from the data points in various databases.
- Configure monitoring conditions based on the real-time values of data points. When the predefined conditions are met, alert notifications are triggered.
- Present real-time and historical data from data points in custom charts, graphs, and dashboards without any coding.
- Run on Windows, Linux, or Docker, and supports x86, x64, arm, and arm64 architectures.



## Frequently Asked Questions

Refer to [FAQ](./FAQ.md)s.

​     



   
