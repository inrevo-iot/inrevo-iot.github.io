---
sidebar_position: 4
---

# File Resource Selector

The following image shows the interface of the file resource selector.

<div className="img">![media-1](./img/media-1.png)</div>

#### Features

| No.     | Description    |
| -------- | ------- |
| 1        | File directory |
| 2        | Zoom out image |
| 3        | Zoom in image |
| 4        | Current size of the image preview |
| 5        | Add new directory |
| 6        | Delete directory |
| 7        | Upload image |
| 8        | Delete image |
| 9        | List of images in the current directory |
| 10       | Information display of selected image; options to cancel or select below. |
