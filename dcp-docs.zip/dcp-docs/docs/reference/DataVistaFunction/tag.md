---
sidebar_position: 5
---

# Point Association

Many components can associate with points to dynamically set some data. The main types include:

#### 1. Directly associate point values, such as: Text components, dashboards, scales, etc.

<div className="img">![tag-1](./img/tag-1.png)</div>

#### 2. Set text based on point values, such as: Link components, text areas, etc.

<div className="img">![tag-3](./img/tag-3.png)</div>

#### 3. Set images based on point values, such as: Image components.

<div className="img">![tag-4](./img/tag-4.png)</div>

## Point Selector

All three types of point associations require selecting specific points to associate, which can be done using the point selector below.

<p>The point groups are displayed on the left side of the point selector, while the list of points under the selected group is shown on the right side.</p>

<p>There is a filter above the list that allows for quick filtering of point names that need to be matched.</p>

<div className="img">![tag-2](./img/tag-2.png)</div>
