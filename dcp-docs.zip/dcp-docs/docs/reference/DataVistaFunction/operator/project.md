---
sidebar_position: 1
---

# Project

## Create a Project

In the sidebar, select Data Vista / Projects to enter the Data View module. You will see the following page：

![project-1](./img/project-1.png)

You will notice that there are no projects under the Data View module, so you need to create a project first. Click "Create Project," and a popup will appear for creating a project：

![project-2](./img/project-2.png)

Enter the project name and click the "Save" button. You have successfully created a project.

![project-3](./img/project-3.png)


## Delete a Project

There is a delete icon next to the project name. Click the icon to delete the project.