---
sidebar_position: 1
---

# Screen

## Create Screen

Expand the project, and you will see a "Create Screen" button. Click on "Create Screen," and a pop-up for creating a Screen will appear：

![project-4](./img/project-4.png)

![project-5](./img/project-5.png)

Enter the Screen name, click the "Save" button, and you have successfully created a Screen.

## Edit Screen

<p>Select a screen, and you will see the interface shown below.</p>

![screen-0](./img/screen-0.png)

<p>Label ① indicates the current location in the project's screen list.</p>
<p>Label ② is the screen's edit button; clicking label ② will enter edit mode.</p>

<p>Label ③ is the screen's sharing feature; shared pages can be accessed directly. Sharing can also be canceled, and canceled shares will no longer be accessible.</p>
<p>Label ④ is the full-screen toggle icon; clicking this icon switches to full-screen display within the webpage.</p>
<p>Clicking label ⑤ toggles the display of the left sidebar.</p>

Click label ② to enter edit mode.
![screen-01](./img/screen-1.png)

| Number     | Description    |
| -------- | ------ |
| 1        | Bring the selected component to the top.    |
| 2        | Send the selected component to the bottom.    |
| 3        | Move the selected component up one layer.    |
| 4        | Move the selected component down one layer.    |
| 5        | Left-align the selected component.    |
| 6        | Right-align the selected component.    |
| 7        | Top-align the selected component.    |
| 8        | Bottom-align the selected component.    |
| 9        | Undo action.    |
| 10       | Redo action.    |
| 11       | Component tab; this tab displays the components that can be added to the page. Click on the component icons below to add them directly to the page.    |
| 12       | Edit tab for Screen or component properties. If no components are selected, it displays the Screen's property editing module; if components are selected, it displays the component's property editing module.    |
| 13       | Icon to toggle the state of the right-side window.    |
| 14       | Close button; clicking this will collapse the right-side configuration window.    |

View Property Editing Module

<div className="img">![screen-3](./img/screen-3.png)</div>

Component Property Editing Module

<div className="img">![screen-4](./img/screen-4.png)</div>

#### Shortcut Key Support
| Shortcut Key     | Description    |
| --------  | ------ |
| Ctrl + C     | Copy the selected component.    |
| Ctrl + V     | Paste the selected component.    |
| Delete     | Delete the selected component.    |


#### Mouse Operation Support
| Action     | Description    |
| --------  | ------ |
| Move      | Hover over the component until the <span className="inline-img">![screen-5](./img/screen-5.png)</span>icon appears, then drag the component.    |
| Resize  | Hover over the edges and corners of the component to resize its area.    |
| Rotate      | Hover over the <span className="inline-img">![screen-6](./img/screen-6.png)</span>icon in the upper right corner of the component to rotate it.    |


## Delete Screen

Click the delete icon on the right side of the screen list to delete the screen.

![screen-del-confirm](./img/screen-del-confirm.png)
