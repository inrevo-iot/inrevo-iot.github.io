---
sidebar_position: 3
---

# Common Configuration

## Position and Size
Configure the component's position in the view and the size of the occupied area.

<div className="img">![conf-pos](./img/conf-pos.png)</div>

#### Features

| Property     | Type     | Description    |
| -------- | ------- | ------- |
| x        | number    | Distance from the left of the page |
| y        | number    | Distance from the top of the page |
| width    | number    | Width of the component |
| height   | number    | Height of the component |

## Background Color and Border
Configure the component's background color and border thickness, style, and color.

<div className="img">![conf-bg](./img/conf-bg.png)</div>

#### Features

| Property     | Type     | Description    |
| -------- | ------- | ------- |
| color(background)  | color           | Background color of the component |
| size               | number          | Border width of the component |
| style              | select Options  | Configuration of border style |
| radius             | number          | Border corner radius |
| color(border)      | number          | Border color of the component |

## Margin
Configure the component's margin.

<div className="img">![conf-padding](./img/conf-padding.png)</div>

#### Features

| Property     | Type     | Description    |
| -------- | ------- | ------- |
| left     | number  | Left margin of the component |
| right    | number  | Right margin of the component |
| top      | number  | Top margin of the component |
| bottom   | number  | Bottom margin of the component |

## Font Configuration
Configure font-related properties.

<div className="img">![conf-font](./img/conf-font.png)</div>

#### Features

| Property     | Type     | Description    |
| -------- | ------- | ------- |
| font family     | Select Options  | Font options |
| size            | number          | Font size |
| line-height     | number          | Line height of the font |
| style           | check Options   | Font styles: bold, italic, underline, strikethrough |
| align           | check Options   | Text alignment: left, center, right, top, middle, bottom |
| color           | color           | Font color |

## Flash Configuration
Configure parameters for flashing alerts.

<div className="img">![conf-flash](./img/conf-flash.png)</div>

#### Features

| Property     | Type     | Description    |
| -------- | ------- | ------- |
| enable    | boolean     | Whether the component flashes |
| rate      | number      | Duration of the flash |
| count     | number      | Number of flashes |

## Events
Configure events triggered by clicks or changes on components.

<div className="img">![evt-none](./img/evt-none.png)</div><div className="img">![evt-2](./img/evt-2.png)</div>

#### Features

| Property     | Type     | Description    |
| -------- | ------- | ------- |
| Action    | Select Options     | Event types: None, Set value at point, Go to a specific view, Go home, Go to a specific URL |

#### Default Value: None

Does not trigger any events.

#### Set Value at Point

Select "Set tag" from the Action dropdown, then click in the input box below "Set a tag" to open a point selector. Finally, choose a component (e.g., input component) from the dropdown at the bottom to assign the input value to the set point when the event is triggered.

Step 1.

<div className="img">![evt-tag-1](./img/evt-tag-1.png)</div>

Step 2.

<div className="img">![evt-tag-2](./img/evt-tag-2.png)</div>
<div className="img">![evt-tag-3](./img/evt-tag-3.png)</div>

Step 3.

<div className="img">![evt-tag-4](./img/evt-tag-4.png)</div>
<div className="img">![evt-tag-5](./img/evt-tag-5.png)</div>

#### Go to a Specific Screen

Select "Go to Screen" from the Action dropdown, then choose the view to navigate to from the dropdown below "Screen."

<div className="img">![evt-screen-1](./img/evt-screen-1.png)</div>
<div className="img">![evt-screen-2](./img/evt-screen-2.png)</div>

#### Go Home

Simply select "Go Home" from the Action dropdown.

<div className="img">![evt-home](./img/evt-home.png)</div>

#### Go to a Specific URL

Select "Go to URL" from the Action dropdown, then enter the link address in the input box below "URL."

<div className="img">![evt-url](./img/evt-url.png)</div>