---
sidebar_position: 7
---

# Data Table

This component is used to display historical data for selected points within a specific time range.

<div className="img">![data-1](./img/data-1.png)</div>

## Features

| Property     | Type     | Description    |
| -------- | ------- | ------- |
| Tags      | Tag Array   |  List of points associated with the component |


## Settings

<div className="img">![data-2](./img/data-2.png)</div>

Click the input box to open the point association window and set associated points for the component. Click the "Add Option" button to add associated points.

## Table Features

| Property     | Type     | Description    |
| -------- | ------- | ------- |
| font color (header)      | Color   |  Text color of the table header |
| bg color (header)        | Color   |  Background color of the table header |
| font color (row)         | Color   |  Text color of the table content |
| bg color (row)           | Color   |  Color	Background color of the table row |
| grid color (row)         | Color   |  Border color of the table row |

## Table Parameter Settings

<div className="img">![realtime-3](./img/realtime-3.png)</div>


## Table Column Description

| Property     | Type     | Description    |
| -------- | ------- | ------- |
| Data Time      | time   |  Time when the data for the collection point was recorded |
| Other Columns      | Tag   |  Values corresponding to the selected points at the given time |


## Filtering

You can filter the displayed data for a specific time range using the date range option in the top right corner of the component.