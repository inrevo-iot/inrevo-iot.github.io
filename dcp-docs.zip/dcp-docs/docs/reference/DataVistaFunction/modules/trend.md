---
sidebar_position: 9
---

# Trend

This component is used to display data trends over a recent period of time.

<div className="img">![trend-1](./img/trend-1.png)</div>

<p></p>
In the top left corner, you can select the option to display historical data. Once selected, a date range picker will appear. Choose the desired historical range for display in the chart below.

<div className="img">![trend-3](./img/trend-3.png)</div>

<p></p>
Click the "Play" button in the top right corner to display point data in a time-series format.

## Chart Features

| Property     | Type     | Description    |
| -------- | ------- | ------- |
| Tags         | Tag Array   |  List of points associated with the component |
| Tag Config   | Trend Option Array  |  Configuration for each point's trend chart |
| - line color | Color     |  The color of the trend line |
| - fill       | boolean   |  Whether the area between the line and axis is filled with color |
| - y-min      | number    |  Minimum value for the Y-axis |
| - y-max      | number    |  Maximum value for the Y-axis |
| - y-step     | number    |  Interval for Y-axis ticks |
| - y-axis     | Check Options   |  Position of the Y-axis (left or right) |
| - show y-axis| boolean   |  Whether to display the Y-axis |

## Point Association and Display Settings

<div className="img">![trend-2](./img/trend-2.png)</div>
