---
sidebar_position: 14
---

# Select

This component allows you to create a dropdown menu and supports defining change [events](/docs/reference/DataVistaFunction/conf#events).

<div className="img">![select-1](./img/select-1.png)</div>
<div className="img">![select-3](./img/select-3.png)</div>


## Features

| Property     | Type     | Description    |
| -------- | ------- | ------- |
| value     | Text     | Default selected item or dynamically set based on point status |
| options   | check Options     | Specific items for the dropdown menu |

## Configuration
<div className="img">![select-2](./img/select-2.png)</div>

<p></p>
For additional features, please refer to the [Common Configuration](/docs/reference/DataVistaFunction/conf).