---
sidebar_position: 10
---

# Button

This component is used to provide standard click events for user interaction. For specific supported events, refer to [“Common Component Configuration”](/docs/reference/DataVistaFunction/conf#events).
<p></p>
The component allows you to add static text or associate point data for display.

<div className="img">![button-1](./img/button-1.png)</div>


## Features

| Property     | Type      | Description    |
| -------- | ------- | ------- |
| Text     | Text     | The text displayed on the button |

For other features, such as [Margins](/docs/reference/DataVistaFunction/conf#margin) and [Font Configuration](/docs/reference/DataVistaFunction/conf#font-configuration), please refer to the common component configuration.
