---
sidebar_position: 15
---

# Textarea

This component allows you to create a text area and supports defining change [events](/docs/reference/DataVistaFunction/conf#events).

<div className="img">![textarea-1](./img/textarea-1.png)</div>


## Features

| Property     | Type     | Description    |
| -------- | ------- | ------- |
| content     | Text     | Supports setting default display text and configuring default text based on point data |

## Configuration
<div className="img">![textarea-2](./img/textarea-2.png)</div>


#### Associating Dynamic Point Data

Click the point icon <span className="img-top">![img-6](./img/img-6.png)</span> to open the point association window, set the associated point, and configure the corresponding text content.

<p></p>
For additional features, please refer to the [Common Configuration](/docs/reference/DataVistaFunction/conf).