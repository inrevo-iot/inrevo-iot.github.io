---
sidebar_position: 16
---

# Switch

This component allows you to create a switch that toggles between "On" and "Off" states. It also supports defining change [events](/docs/reference/DataVistaFunction/conf#events).

<div className="img">![switch-1](./img/switch-1.png)</div>


## Features

| Property     | Type     | Description    |
| -------- | ------- | ------- |
| defaultColor    | Color     | The default color of the switch |
| activeColor     | Color     | The color when the switch is in the "On" state |

## Configuration
<div className="img">![switch-2](./img/switch-2.png)</div>


<p></p>
For additional features, please refer to the [Common Configuration](/docs/reference/DataVistaFunction/conf).