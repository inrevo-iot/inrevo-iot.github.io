---
sidebar_position: 1
---

# Image

This component allows you to specify static or dynamic images for display in the Screen.

<div className="img">![img-1](./img/img-1.png)</div>

## Features

| Property     | Type     | Description    |
| -------- | ------- | ------- |
| Default Media | Img Path          | Path to the default image |
| size          | Select Options    | Image size options: original size, stretch, maintain aspect ratio |
| repeat        | Select Options    | Image repetition options: no repeat, repeat horizontally, repeat vertically, repeat both axes |

#### Image Property Settings

<div className="img">![img-3](./img/img-3.png)</div>

Click the gray box to open [the File Resource Selector](/docs/reference/DataVistaFunction/media) and choose the default image to use.

<div className="img">![img-5](./img/img-5.png)</div>

After selecting an image, you can set the size and repeat properties.

#### Dynamic Image Settings

Click the point icon <span className="img-top">![img-6](./img/img-6.png)</span>  to open the image point association window and set associated points for the component.

<div className="img">![img-7](./img/img-7.png)</div>
