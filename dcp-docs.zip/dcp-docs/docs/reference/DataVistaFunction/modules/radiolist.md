---
sidebar_position: 13
---

# Radiolist

This component allows you to create a radio button list and supports defining component change [events](/docs/reference/DataVistaFunction/conf#events).

<div className="img">![radiolist-1](./img/radiolist-1.png)</div>


## Features

| Property     | Type     | Description    |
| -------- | ------- | ------- |
| value     | Text     | Default selected item or dynamically set based on point status; multiple values should be separated by commas |
| options   | check Options     | The specific items for the radio buttons |

## Configuration
<div className="img">![radiolist-2](./img/radiolist-2.png)</div>

<p></p>
 For additional features, please refer to the [Common Configuration](/docs/reference/DataVistaFunction/conf).