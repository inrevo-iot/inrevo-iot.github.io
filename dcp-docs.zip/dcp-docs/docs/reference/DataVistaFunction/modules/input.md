---
sidebar_position: 11
---

# Input

This component provides standard text input, allowing you to bind the component's value in events to assign values to other points.
<p></p>
The component can be associated with points. When the page loads, if points are associated, their data will be displayed in the component. However, if the associated points change afterward, the component will not update automatically. For real-time display of point data, consider using the [Text Component](/docs/reference/DataVistaFunction/modules/text).
<p></p>
Additionally, this component supports [change events](/docs/reference/DataVistaFunction/conf#events); if the value in the input box changes, the bound event will be triggered.


<div className="img">![input-1](./img/input-1.png)</div>


## Features

| Property     | Type     | Description    |
| -------- | ------- | ------- |
| Text     | Text     | Input text |

For other features, such as [Margins](/docs/reference/DataVistaFunction/conf#margin) and [Font Configuration](/docs/reference/DataVistaFunction/conf#font-configuration), please refer to the common configuration for components.
