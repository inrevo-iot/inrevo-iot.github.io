---
sidebar_position: 5
---

# Scale

This component can be associated with point data, allowing real-time updates to display point information.

<div className="img">![scale-1](./img/scale-1.png)</div>

## Features

| Property     | Type     | Description    |
| -------- | ------- | ------- |
| value      | Number   | Tag Value    \| Static value or point value |
| min        | Number   | Minimum value of the scale |
| max        | Number   | Maximum value of the scale |
| arc width  | Number   | Width of the scale |
| font size  | Number   | Font size of the scale |
| base color | Color    | Background color of the scale |
| arc color  | Color    | Foreground color of the scale |
| font color | Color    | Font color of the scale |
| duration | Check Options    | Orientation of the scale: vertical or horizontal (default is vertical) |

## Settings

<div className="img">![scale-2](./img/scale-2.png)</div>

Click the point icon next to the value <span className="img-top">![img-6](./img/img-6.png)</span> to open the point association window. You can associate points with the component to display real-time point values.