---
sidebar_position: 3
---

# Link

The Link component allows you to define static or dynamic links, enabling users to click and navigate the web browser to another destination. Links can be external, pointing to websites or pages outside, or internal, linking to specific project screens. This is particularly useful for building navigation.

<div className="img">![link-1](./img/link-1.png)</div>

## Features

| Property     | Type     | Description    |
| -------- | ------- | ------- |
| Url      | Text     | Link address |
| Text     | Text     | Link text |
| Font     | Font Options    | Font-related configurations |
