---
sidebar_position: 6
---

# RealTime

This component is used to display real-time data for points in a table format.

<div className="img">![realtime-1](./img/realtime-1.png)</div>

## Features

| Property     | Type     | Description    |
| -------- | ------- | ------- |
| Tags      | Tag Array   |  List of points associated with the component |


## Settings

<div className="img">![realtime-2](./img/realtime-2.png)</div>

Click the input box to open the point association window and set associated points for the component. Click the "Add Option" button to add points.

## Table Features

| Property     | Type     | Description    |
| -------- | ------- | ------- |
| font color (header)      | Color   |  Text color of the table header |
| bg color (header)        | Color   |  Background color of the table header |
| font color (row)         | Color   |  Text color of the table content |
| bg color (row)           | Color   |  Background color of the table row |
| grid color (row)         | Color   |  Border color of the table row |

## Table Parameter Settings

<div className="img">![realtime-3](./img/realtime-3.png)</div>
