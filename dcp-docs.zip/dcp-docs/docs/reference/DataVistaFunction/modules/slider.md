---
sidebar_position: 17
---

# Slider

This component allows you to create a progress bar that lets you adjust the displayed value within a specified range. It also supports defining change [events](/docs/reference/DataVistaFunction/conf#events).

<div className="img">![slider-1](./img/slider-1.png)</div>


## Features

| Property     | Type     | Description    |
| -------- | ------- | ------- |
| value    | number     | The default displayed value, can be associated with point data |
| min      | number     | The minimum value of the slider |
| max      | number     | The maximum value of the slider |
| step     | number     | The step value when dragging the slider |
| base color     | Color     | Background color of the slider |
| arc color      | Color     | Fill color of the slider |
| font color     | Color     | Font color of the slider |
| duration       | boolean     | Display direction: horizontal by default, vertical when unchecked |

## Configuration
<div className="img">![slider-2](./img/slider-2.png)</div>


<p></p>
For additional features, please refer to the [Common Configuration](/docs/reference/DataVistaFunction/conf).