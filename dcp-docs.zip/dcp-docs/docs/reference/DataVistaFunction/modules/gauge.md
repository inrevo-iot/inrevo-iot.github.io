---
sidebar_position: 4
---

# Gauge

This component allows you to associate point data and updates the displayed information in real time.

<div className="img">![gauge-1](./img/gauge-1.png)</div>

## Features

| Property     | Type     | Description    |
| -------- | ------- | ------- |
| value      | Number   | Tag Value    \| Static value or point value |
| min        | Number   | Starting value of the gauge |
| max        | Number   | Ending value of the gauge |
| arc width  | Number   | Width of the gauge arc |
| font size  | Number   | Font size of the gauge text |
| base color | Color    | 	Background color of the gauge |
| arc color  | Color    | Foreground color of the gauge |
| font color | Color    | Color of the gauge text |

## Settings

<div className="img">![gauge-2](./img/gauge-2.png)</div>

Click the point icon next to the value <span className="img-top">![img-6](./img/img-6.png)</span> to open the point association window. Here you can set associated points for the component, allowing for real-time display of point values.