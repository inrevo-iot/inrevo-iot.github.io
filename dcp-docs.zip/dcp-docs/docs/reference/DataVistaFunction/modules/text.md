---
sidebar_position: 2
---

# Text

This component allows you to add static text to a view or associate it with point data for display.

<div className="img">![text-1](./img/text-1.png)</div>

## Features

| Property     | Type     | Description    |
| -------- | ------- | ------- |
| Text     | Text     | The text content |

#### Text Property Settings

<div className="img">![text-2](./img/text-2.png)</div>

#### Associating Dynamic Point Data

Click the point icon <span className="img-top">![img-6](./img/img-6.png)</span> to open the point association window and associate point data with the component.

<div className="img">![text-3](./img/text-3.png)</div>