---
sidebar_position: 12
---

# Checklist

This component allows you to create a checklist and supports defining changes through [events](/docs/reference/DataVistaFunction/conf#events).

<div className="img">![checklist-1](./img/checklist-1.png)</div>


## Features

| Property     | Type     | Description    |
| -------- | ------- | ------- |
| value     | Text     | The specific items that are checked by default or dynamically set based on status, separated by commas. |
| options   | check Options     | The specific items in the checklist. |

## Configuration
<div className="img">![checklist-2](./img/checklist-2.png)</div>

<p></p>
For other features, please refer to [Common Configuration](/docs/reference/DataVistaFunction/conf).