---
sidebar_position: 8
---

# Alarm

This component is used to display alarm information from the recent past.

<div className="img">![alarm-1](./img/alarm-1.png)</div>

## Table Features

| Property     | Type      | Description    |
| -------- | ------- | ------- |
| font color (header)      | Color   |  Text color for the table header |
| bg color (header)        | Color   |  Background color for the table header |
| font color (row)         | Color   |  Text color for the table content |
| bg color (row)           | Color   |  Background color for table rows |
| grid color (row)         | Color   |  Border color for table rows |
| Level Grid Color         | Color   |  Color	Background color for rows of different alarm levels that are not closed |

## Table Parameter Settings

<div className="img">![realtime-3](./img/realtime-3.png)</div>

## Alarm Level Color Settings

<div className="img">![alarm-2](./img/alarm-2.png)</div>


## Table Column Descriptions

| Property     | Type      | Description    |
| -------- | ------- | ------- |
| Data Time      | time   |  Time of data collection for the point |
| Other Columns      | Tag   |  Tag	Values corresponding to the selected point's time |


## Filtering

You can filter the displayed data using the input box at the top left corner of the component.