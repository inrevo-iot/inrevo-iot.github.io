---
sidebar_position: 2
---

# Datacollection Troubleshooting

After you have configured the drivers, point groups, and data points according to [Data Collection](/docs/Qickstart/DataCollection), if data is not collected properly, You can view the points' status (Quality) through the [Data Query](/docs/Qickstart/DataNavigation#data-query) page.

| Status(Quality) Code | Description                | Resolve Method                                               |
| -------------------- | -------------------------- | ------------------------------------------------------------ |
| 192                  | normal                     | -                                                            |
| 400                  | execution error            | check if the device is operating normally.                   |
| 404                  | socket error               | check if the driver parameters are correct and if the device is operating normally. |
| 501                  | serializable extract error | please refer to the device manual to configure the correct data address. |
| 502                  | serializable param empty   | please  configure the correct data point parameters.         |
| 503                  | address is not writable    | please refer to the device manual to configure the correct address for writable data. |
| 504                  | param type not supported   | please refer to the device manual to configure the correct data type. |

