---
sidebar_position: 1
---

# System Troubleshooting

## Can not access the Inrevo IOT Web UI issue

Generally, You can connect to the Inrevo IOT Node / Monitor from a browser using the network IP address and port (default is 51000/52000) for the machine or computer on which the Inrevo IOT Node / Monitor is installed. 

If you can not access the Inrevo IOT Web UI:

First, check the Inrevo IOT node/monitor process status to see whether the iot system is running properly.

`windows:`

`uses the task manager to check whether related tasks (inrevo-iot-node/inrevo-iot-monitor) are normal`



`linux:`

`systemctl status inrevo-node`

`systemctl status inrevo-monitor`



`docker:`

`docker ps | grep inrevo`



If related processes are running abnormally, check whether the ports are occupied, refer to [Port requirements](/docs/Qickstart/SystemRequirements#port-requirements). 

If related processes are running properly, then check whether related ports are allowed through the firewall. 





