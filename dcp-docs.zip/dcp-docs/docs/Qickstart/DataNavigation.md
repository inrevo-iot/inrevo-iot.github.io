---
sidebar_position: 5
---

# Data Navigation

Once the device's data has been successfully collected, you can query and access it in various ways.

​    

## Data Query

On the Data Query / Points page, you can query the real-time values of the data points.

![image-20240926143329236](.\img\data-query.png)

​    

## OPC UA Server

Inrevo IOT system starts an OPC UA Server (if Enabled) to provide data for third-party access. 

The OPC UA server on the Inrevo IOT node provides only the data collected by that node. The OPC UA server on the Inrevo IOT monitor provides data from all nodes connected to the monitor.

Refer to the System Settings / Options / [OPC UA Server](./AccesstheWebUI#opc-ua-server) page to get the OPC UA Server connection parameters.

You can use an OPC UA client or  through programming to connect to the OPC UA server of this system and retrieve data. 

Endpoint Url format is: `opc.tcp://{ip}:{ua server port}/inrevo`

For instance, assume the IP address of the machine or computer running this system is 192.168.101.150, the ua service port you have set is 53530, then the endpoint Url is:

opc.tcp://192.168.101.150:53530/inrevo

![image-20240926143643132](.\img\opcua-connect-demo.png)

After successfully connecting, you can browse the data. 

The data is organized in the following format:

`inrevo/{node id}/{group name}/{point name}`

![image-20240926143809322](.\img\opcua-browser-data.png)

​    

## Database

The real-time and historical data (if Enabled) of the data points have been saved to the database server you chose, with the database name set to inrevodata, includes following 3 tables/measurements.

| Table/Measurement |                   Usage                   |
| :---------------: | :---------------------------------------: |
|       data        |   stores real-time data of data points    |
|   data_history    | stores historical data of the data points |
|   alarm_record    |           stores alarm records            |

Refer to the System Settings / Options / [Database](./AccesstheWebUI#database) page to get the database connection parameters.

The database used by the Inrevo IOT node provides only the data collected by that node. The database used by the Inrevo IOT monitor provides data from all nodes connected to the monitor.

You can use a database client or through programming to connect to the database server used by this system and retrieve data. 

​    

## Data Vista

Data Vista is a no-code web user interface tool.

With Data Vista, you can present real-time and historical data of data points in custom charts, graphs, and dashboards without any coding, simplifying the creation of visual data applications.

Refer to [Data Vista](./DataVista) to use it.

​    

