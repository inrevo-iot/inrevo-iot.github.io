---
sidebar_position: 1
---

# System Requirements

The Inrevo IoT system is designed to collect, process, and forward data. These operations require substantial computational resources to ensure timely data processing.



## Factors affecting resource consumption

The main factors affecting resource consumption and system performance include:

- Number of data points

The more data points there are, the more computational and storage resources are required.

- Data collection interval

The shorter the data collection interval, the more computational resources are required.

- Number of data points with configured alarms

Additional computational resources are required to determine whether an alarm should be triggered.

- Number of data points with configured calculation formulas

Additional computational resources are required to perform calculations based on the configured formulas.

- Duration of historical data storage

The longer the historical data retention period, the more storage and computational resources are required for storage and access.

- Number of concurrent connections to the OPC UA server

The more concurrent connections, the more computational resources are required.

- Number of web/applications access to this system

The more applications, the more computational resources are required.



## Recommended Configurations

Please refer to the table below to set up your computer or machine. When data latency (in data entry) is detected, either reduce the collection frequency or the number of data points, or increase the hardware resources (CPU Cores, memory).

|                                                      | Scenario 1 | Scenario 2 | Scenario 3 |
| ----------------------------------------------------- | ---------- | ---------- | ---------- |
| number of data points                                 | < 500      | < 1000     | > 1000     |
| number of concurrent web or application connections   | &lt;= 2 | &lt;= 10 | > 10       |
| duration of historical data storage                   | &lt;= 7 days | &lt;= 30 days | > 30 days  |
| number of concurrent connections to the OPC UA server | &lt;= 2 | &lt;= 10 | > 10       |
| CPU Cores                                             | >= 4      | >= 8      | >= 12     |
| CPU frequency                                         | >= 1.0GHz | >= 2.0GHz | >= 3.0GHz |
| Memory(RAM)                                           | >= 4 GB   | >= 8GB    | >= 16GB   |
| Storage                                               | >= 100GB  | >= 150GB  | >= 200GB  |
| network interface                                     | It is recommended that your machine or computer has two network interfaces, one for southbound (OT) and one for northbound (IT) communication. |It is recommended that your machine or computer has two network interfaces, one for southbound (OT) and one for northbound (IT) communication.|It is recommended that your machine or computer has two network interfaces, one for southbound (OT) and one for northbound (IT) communication.|



## Operating system and CPU architecture Requirements

The supported operating systems include Windows 64-bit, Linux 64-bit, and Linux 32-bit.

The supported CPU architectures include x64 (amd64), arm64 (aarch64), and arm.



## Port requirements

This system uses the following default ports: 

| Port  |                Purpose                |
| :---: | :-----------------------------------: |
| 51000 |   Inrevo IOT node web service port    |
| 61000 |    Inrevo IOT driver service port     |
| 53530 |  Inrevo IOT node OPC UA Server port   |
| 52000 |  Inrevo IOT monitor web service port  |
| 53531 | Inrevo IOT monitor OPC UA Server port |

Please ensure that these ports are not used by other applications and that the firewall is configured to allow traffic on these ports. If the default ports are adjusted during deployment, please update the firewall settings to reflect these changes.
