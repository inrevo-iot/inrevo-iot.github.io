---
sidebar_position: 3
---

# Access the Web UI

After successfully installing Inrevo IOT system, you can access the Web UI from a browser.



## Node side

### Access from a Browser

You can connect to the Inrevo IOT Node from a browser using the network IP address and port (default is 51000) for the machine or computer on which the Inrevo IOT Node is installed. 

For instance, suppose the IP address of your machine or computer is 192.168.101.150, enter

 http://192.168.101.150:51000

 in your browser to access the web interface.



### Log in to the Inrevo IOT Node Web

![image-20240924165247998](.\img\login.png)



default administrator account of Inrevo IOT Node is:

| username | password |
| -------- | -------- |
| admin    | inrevo   |

You can change the password later.

​    

### System Settings

After logging in, you can manage users, modify system parameters, and activate the system.

   ![image-20240924174258467](.\img\settings.png)



#### User manage

You can Add/Delete/Modify users

   ![image-20240924171453751](.\img\user.png)

| Security Group | Authority                                                    |
| -------------- | ------------------------------------------------------------ |
| Administrator  | can access all functions.                                    |
| Operator       | can access Device drivers, Data Points, Data Query, Data Vista. |
| User           | can access Data Query, Data Vista.                           |

​    

#### Options

##### Device Drivers

Maximum driver number - set the maximum driver number can be created on this node.

*note:  It is recommended not to exceed twice the number of CPU cores on the machine.*

##### History

Enable - whether to store historical data.

Maximum retention time - set the maximum number of days to retain historical data (including alarm data).

##### Database

You can select a database type and enter the connection parameters for storing real-time and historical data for the data points. 

The currently supported database types are SQLite, MariaDB, MySQL, SQL Server, PostgreSQL, Oracle, and InfluxDB.

1. SQLite

![image-20240924165843852](.\img\sqlite.png)

Specify a sqlite db path on your machine or computer, the Inrevo IOT system will create the sqlite DB automatically.

*Note: SQLite is intended for testing purposes only and should not be used in a production environment.*



2. MariaDB, MySQL, SQL Server, PostgreSQL, Oracle, and InfluxDB

   You need to install and prepare the database you want to choose in advance.

   Enter the database IP, port, username, password, and so on as indicated in the image. 

   ![image-20240924170025291](.\img\db.png)

   

   *Note:* 

    *(1) The database account must have permissions to create databases and perform CRUD (create, read, update, delete)  operations.*

    *(2) The requirements for the database version are:*

   *MariaDB 10.2+*

   *MySQL 5.7+*

   *PostgreSQL  9.5+*
   
   *SqlServer 2012+*
   
   *Oracle 11g+*
   
   *InfluxDB v2.0+*

##### OPC UA Server

Inrevo IOT starts an OPC UA Server (if Enabled) to provide data for third-party access. You can set the parameters for the OPC UA server.

![image-20241121175623268](.\img\opcua.png)

​       **Enable**: Whether to enable the OPC UA Server



##### Connect to monitor

Inrevo IOT node can connect to the Inrevo IOT monitor.

![image-20240924170504734](.\img\connect2monitor.png)

Key parameters description:

**Enable**: Whether to enable the connection

**Unidirectional**: If selected, it indicates unidirectional transmission, meaning the monitoring node can only read from this node; otherwise, it indicates bidirectional transmission, meaning the monitoring node can both read and write to this node.

Enter the IP, Port, Username, and Password of the Inrevo IOT monitor you want to connect to.

 

##### Forward to cloud

Inrevo IOT node can forward (if Enabled) OT data to Cloud. 

![image-20241121181354649](.\img\cloud.png)

Key parameters description:

**Target**: Data receiving destination. The currently supported target types are Kafka, MQTT and AWS IoT.

**Buffer Data**: When the network to Cloud fails, the Inrevo IoT Node will buffer OT data to database you have selected.  When the network is restored, the Inrevo IoT Node will immediately resume transmitting all the data collected during the network outage to the cloud platform, ensuring the integrity and accuracy of the cloud data. This parameter determines the number of days the data is cached. 0 means no caching.

**Server Address**: Target's IP:Port or URL.  Format examples are as follows:

|       Target       |                   Server Address                   |
| :----------------: | :------------------------------------------------: |
|       Kafka        | 192.168.3.3:9092,192.168.3.4:9092,192.168.3.5:9092 |
|        MQTT        |                  192.168.3.3:1883                  |
| MQTT (SSL enabled) |                  192.168.3.3:8883                  |
|      AWS IoT       |    xxx-ats.iot.cn-northwest-1.amazonaws.com.cn     |



​    

#### Notification

You can configure alert notifications, which will be sent via email or SMS when the point data meets predefined conditions and triggers an alert.

##### E-Mail Notification

![image-20240924170735814](.\img\email.png)

To enable E-Mail as a notification type you will need to enable SMTP service for your email account according to the instructions on your email server provider's website and obtain an authorization code to use as the password.

The email server format is server_address:port, Here are some examples:

| email server format       | to enable SMTP service                                       |
| ------------------------- | ------------------------------------------------------------ |
| smtp.gmail.com:587        | enable [SMTP](https://help.accredible.com/s/article/smtp-setup-in-gmail-inbox?language=en_US) |
| smtp-mail.outlook.com:587 | enable [SMTP](https://support.microsoft.com/en-us/office/pop-imap-and-smtp-settings-for-outlook-com-d088b986-291d-42b8-9564-9c414e2aa040) , enable [Two-step verification](https://support.microsoft.com/en-us/account-billing/how-to-use-two-step-verification-with-your-microsoft-account-c7910146-672f-01e9-50a0-93b4585e7eb4) and enable [OAuth 2.0 authorization](https://docs.microsoft.com/en-us/azure/active-directory/develop/v2-oauth2-auth-code-flow) for sending notifications.  And concatenate tenant, client_id, and client_secret in the format tenant:client_id:client_secret to form the Password |



##### SMS Notification

![image-20240924171814648](.\img\sms.png)

To enable SMS as a notification type you will need to use the [Twilio service](https://www.twilio.com).

Enter your Twilio Phone Number, account SID, Authentication Token and receiving phone numbers.

​     

#### License

You need a license to activate the system and use the full service. Without a valid license, you cannot collect data (including adding drivers, configuring points, and storing data).

Copy the license code and send it to the Inrevo sales team to obtain a license key. Then input this license key and click “Activate” to activate the Inrevo IOT system.

![image-20240924172021611](.\img\license.png)



## Monitor side

### Access from a Browser

you can connect to the Inrevo IOT Monitor from a browser using the network IP address and port (default is 52000) for the machine or computer on which the Inrevo IOT Monitor is installed. 

For instance, suppose the IP address of your machine or computer is 192.168.101.160, enter

 http://192.168.101.160:52000 

in your browser to access the web interface.

​    

### Log in to the Inrevo IOT Monitor Web

![image-20240924172328517](.\img\monitor.png)

default administrator account of Inrevo Monitor Node is:

| username | password |
| -------- | -------- |
| super    | inrevo   |

You can change the password later.

​    

### System Settings

After logging in, you can modify system parameters and activate the system.   

#### Options

##### History

Enable - whether to store historical data.

Maximum retention time - set the maximum number of days to retain historical data (including alarm data).

##### Database

You can select a database type and enter the connection parameters for storing real-time and historical data for the data points. 

The currently supported database types are  SQLite, MariaDB, MySQL, SQL Server, PostgreSQL, Oracle, and InfluxDB.

1. SQLite

![image-20240924165843852](.\img\sqlite.png)

Specify a sqlite db path on your machine or computer, the Inrevo IOT system will create the sqlite DB automatically.

*Note: SQLite is intended for testing purposes only and should not be used in a production environment.*



2. MariaDB, MySQL, SQL Server, PostgreSQL, Oracle, and InfluxDB

   ![image-20240924170025291](.\img\db.png)

   Enter the database IP, port, username, and password as indicated in the image. 

   *Note:* 

    *(1) The database account must have permissions to create databases and perform CRUD (create, read, update, delete)  operations.*

    *(2) The requirements for the database version are:*

   *MariaDB 10.2+*

   *MySQL 5.7+*

   *PostgreSQL  9.5+*

   *SqlServer 2012+*

   *Oracle 11g+*

   *InfluxDB v2.0+*

##### OPC UA Server

Inrevo IOT starts an OPC UA Server  (if Enabled) to provide data for third-party access. You can set the parameters for the OPC UA server. 

![image-20240924172840255](.\img\opcua.png)

​    **Enable**: Whether to enable the OPC UA Server



##### Monitor Authentication

You can set monitor's account (username and password) for Inrevo IOT node to connect.

![image-20240925130755583](.\img\monitor-auth.png)

​    

#### License

You need a license to activate the system and use the full service. Without a valid license, you cannot connect and monitor Inrevo IOT nodes.

Copy the license code and send it to the Inrevo sales team to obtain a license key. Then input this license key and click “Activate” to activate the Inrevo IOT system.

![image-20240924173425212](.\img\monitor-lic.png)

​    

### Nodes Management

Once the Inrevo IOT node connects to the Inrevo IOT Monitor, you can manage the node, including updating node information and accessing the node’s web interface.

![image-20240924173537669](.\img\nodes.png)

​    

