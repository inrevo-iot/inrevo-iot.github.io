---
sidebar_position: 2
---

# Installation

Inrevo IOT system can be deployed to run on Windows, Linux, or Docker, and supports x86, x64, arm, and arm64 architectures.



## Windows Installation

*Note: Only Windows 64-bit (on AMD64) is supported*

### Download

Download [inrevo-iot-node-xxx-setup-x64](https://drive.google.com/file/d/10WxNCkKxgZ4RPI_7fXrkR-d97XB3mT6y/view?usp=sharing) (for node) or [inrevo-iot-monitor-xxx-setup-x64](https://drive.google.com/file/d/10YC93Qi2MA-HDFffxLnnJTcd8-YN7BTq/view?usp=sharing) (for monitor).



### Install

Run inrevo-iot-xxx-setup-x64.exe file and follow the on-screen instructions to complete the installation.



### Upgrade

You need to uninstall the original version first, and then re-install the new version.



## Linux Installation

### Download

Download the appropriate installation package according to your CPU architecture.

[node_x64](https://drive.google.com/file/d/10YKbS0jlW3IFJyzB9QuvR1P1BaH6QdCQ/view?usp=sharing)

[node_x86](https://drive.google.com/file/d/10bq1khvqyckgqFs_QjKHS0ok1mdpmzEj/view?usp=sharing)

[node_arm64](https://drive.google.com/file/d/10d87T4LU026cD71XOXV_wCt6-Hlcwdzr/view?usp=sharing)

[node_arm32](https://drive.google.com/file/d/10cgozAyepm19ghm6AwxhhSWN0_kns2Bv/view?usp=sharing)

 

[monitor_x64](https://drive.google.com/file/d/10lKY9Id9EZaTGsZY6F1Uk-SE9Pzd0TWe/view?usp=sharing)

[monitor_x86](https://drive.google.com/file/d/10n2HJaSItQUORWmyaB83WieVLl_icbs5/view?usp=sharing)

[monitor_arm64](https://drive.google.com/file/d/10kD7jtv167-hSH-hufriQTRbWfPA1res/view?usp=sharing)

[monitor_arm32](https://drive.google.com/file/d/10ifP-facmxnFPm6YvK8-VV5oF2rN-wpp/view?usp=sharing)



### Install

Extract the installation package, then refer to the readme file included in the package for installation instructions.



### Upgrade

Extract the installation package, then refer to the readme file included in the package for upgrading instructions.



## Docker Installation

The Inrevo IOT system is capable of running in Docker containers.

*Note: Only Linux 64-bit (on AMD64 or ARM64) is supported.*

### Prerequisite

1. Install [Docker Engine 20.10+](https://docs.docker.com/engine/install/) on your machine or computer.
2. Install [Docker Compose 2.27+](https://github.com/docker/compose/releases) on your machine or computer.



### Download

Download the appropriate installation script package according to your CPU architecture.

[node_x64](https://drive.google.com/file/d/1-I3l7fcEsKNt02MXBcUvLmfbj9lni_dj/view?usp=sharing)

[node_arm64](https://drive.google.com/file/d/1-MV1EsL_MD_odaFslFNkgBUSoldkpshJ/view?usp=sharing)

 

[monitor_x64](https://drive.google.com/file/d/1-Y308K_RMUzfrmOzibw9RKrED_ylTPEB/view?usp=sharing)

[monitor_arm64](https://drive.google.com/file/d/1-h2BUx4YG6IWOa7s_1SNUcDUA9uyHwDj/view?usp=sharing)



### Install

Extract the installation script package to get docker-compose.yaml file. Then run the installation by using the following command: 

`docker-compose up -d` 



### Upgrade

Perform the following operations in the path where the script package of the original version resides:

(1) Modify the image version number in docker-compose.yaml

(2) Close the old version by running:

    `docker-compose down`

(3）Start the new version by running:

    `docker-compose up -d` 

