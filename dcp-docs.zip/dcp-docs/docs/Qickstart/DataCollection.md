---
sidebar_position: 4
---

# Data Collection

You can configure data collection on the Inrevo IOT node. The process for configuring data collection involves: 

(1) configuring the device driver.

(2) creating a point group.

(3) configuring the data points.



## Device Drivers

Each device has unique connection information, including IP, port, communication method, and protocol. Device drivers are associated with physical devices. Before collecting data, you need to configure the device driver parameters according to the device connection information. 

The currently supported driver types are Modbus, Siemens S7, CNC (Fanuc and Mitsubishi), OPC UA, and OPC DA.

![image-20240924174423694](.\img\drivers.png)

​    

### Driver Introduction

#### Modbus

##### Term Explanation

| Term              | Description                                                  |
| :---------------- | :----------------------------------------------------------- |
| Slave ID          | The MODBUS Slave ID is a unique identifier for a slave device in a MODBUS network. |
| Transmission mode | Refers to the mode used for communication in MODBUS, including RTU (Remote Terminal Unit) , TCP(Transmission Control Protocol) and ASCII (American Standard Code for Information Interchange) modes. |
| Word Swap         | Refers to the process of reordering multi-byte units (words) within a larger data structure. A word is typically 16 bits (2 bytes), 32 bits (4 bytes), or 64 bits (8 bytes). |
| Byte Swap         | Refers to the process of reversing the order of bytes within a multi-byte data unit. |
| Serial port       | A serial port is a communications interface used for transmitting data sequentially. In Windows, serial port names usually start with "COM," such as COM1, COM2, etc. These serial ports are built into the computer and connect through the motherboard's interfaces. In Linux, serial port names begin with "/dev/ttyS," such as /dev/ttyS0, /dev/ttyS1, etc. |



##### Modbus TCP Parameter Example

![image-20240924180539194](.\img\modbus-tcp.png)



##### Modbus RTU Parameter Example

![image-20240924180648745](.\img\modbus-rtu.png)



##### Modbus ASCII Parameter Example

MODBUS ASCII support will be added in future versions.

​    

#### Siemens S7

##### Term Explanation

| Term           | Description                                                  |
| -------------- | ------------------------------------------------------------ |
| Processor type | The currently supported Siemens PLC types, including S7-200, S7-200SMART, S7-300, S7-400, S7-1200 and S7-1500. |

 

##### Siemens S7 Parameter Example

![image-20240924180937494](.\img\s7.png)

​    

#### CNC

##### Term Explanation

| Term | Description                                                  |
| ---- | ------------------------------------------------------------ |
| Type | The currently supported CNC types, including Fanuc (0i-MODEL F Plus, 30i/31i/32i/35i-MODEL) and Mitsubishi (M800/M80, ‌M700V/ ‌M70V and ‌E70). |

***note: The current version does not support running Fanuc drivers under the ARM architecture.***

##### CNC Parameter Example

![image-20240924181114442](.\img\cnc.png)

​    

#### OPC DA

##### Term Explanation

| Term        | Description                                                  |
| ----------- | ------------------------------------------------------------ |
| Domain      | The computer name of the machine where the OPC DA server is located. or it can be set to the IP address of the server computer. |
| Server name | OPC Program Name.                                            |
| Username    | The username is the Windows user name with DCOM permissions. |



##### OPC DA Parameter Example

![image-20240926142414152](.\img\opcda_client.png)

​    

#### OPC UA

##### Term Explanation

| Term                  | Description                                                  |
| --------------------- | ------------------------------------------------------------ |
| Server url            | OPC UA Server Endpoint Url, format is `opc.tcp://ipaddress:port/{servername}` |
| Authentication method | The authentication method supports anonymous and user account methods. |
| Security mode         | Refers to the security settings that define how messages are protected during communication. These modes include None, Sign, and SignAndEncrypt. |
| Security policy       | It defines the security encryption algorithms and settings used to protect communication, including None, Basic128Rsa15, Basic256, Basic256Sha256, Aes128_Sha256_RsaOaep and Aes256_Sha256_RsaPss. |



##### OPC UA Parameter Example

![image-20240924181435426](.\img\opcua-client.png)

​    

### Add Driver

On the drivers page, click Add to create a new driver.

![image-20240924181604613](.\img\add-driver.png)



### Import Drivers

You can import an Excel file containing drivers' information to create them in bulk. 

First, export the Excel template (step 1), fill in the necessary information, and then import the file (step 2).

![image-20240924181700519](.\img\import-drivers.png)



 *Note:* 

*(1) Keep only the header row and remove any old driver information if it is present in the Excel template.*

*(2) You do not need to fill in the driver_id. An example is shown in the figure below.* 

![image-20240924181856786](.\img\import-drivers-demo.png)

*(3) Each Excel file must not exceed 20 MB in size.*

​    

## Data Points

A data point is a specific location or item of data that is measured, collected, or monitored within a system, often used in industrial automation, monitoring, and control systems.

You can create virtual points that are not connected to actual devices but can be calculated (see [the formula section](DataCollection#for-virtual-points-only)) based on other real points.

A point group is a collection of points that are grouped together for easier management.

After configuring the device driver, you can then configure the data points for data collection.



### Group

You can Add/Delete/Modify groups.

![image-20240924182154138](.\img\group-1.png)

![image-20240924182248614](.\img\group-2.png)

​    

### Points Introduction

#### Term Explanation

| Term    | Description                                                  |
| ------- | ------------------------------------------------------------ |
| Address | In industrial data, a point address refers to the specific location or identifier where data is stored or accessed within a device or system. See [Address requirements](DataCollection#address-requirements). |
| Type    | It refers to the specific type of data associated with a particular point or measurement in a system. In Inrevo IOT system, the data types include string, bool, byte, uint16, int16, uint32, int32, int64, float32, float64. |
| Unit    | A data unit refers to the specific unit of measurement used for a data point, such as meters, degrees Celsius, or kilogram. |
| Period  | The data collection period (or interval) in seconds refers to the time interval at which data is collected or sampled from a data point. The minimum period (or interval) is 1 second. |
| Formula | The calculation formula refers to the equation or expression used to compute or derive a value from one or more data points. See [Supported Formulas](DataCollection#supported-formulas). |
| Alarm   | An alarm is a signal or notification indicating that a specific condition or event has occurred, often used to alert operators or systems to take action.<br/>Alarm types include Threshold and Equal.<br/>Alarm levels include 1, 2, 3, 4 and 5, with 1 indicating the highest level.<br/>If the threshold alarm type is selected, you can set the following four thresholds: high high, high, low, and low low.<br/>High High alarm thresholds indicate a more critical condition compared to "high" thresholds. A "high high" threshold is generally set above the "high" threshold to signify a critical situation.<br/>Similarly, in the context of comparing lower values, "low low" means a more severe condition than "low".<br/>If the equal alarm type is selected, you can set the value to compare, and the alarm triggers when the value are equal the data point’s value. |



##### Address requirements

*Note: For each device driver , the point address format has specific requirements.*

(1) Modbus

​    Address description:

| Item             | Description                                                  |
| ---------------- | ------------------------------------------------------------ |
| Address format   | `{modbus data type}{Addr}[.BIT]`                             |
| modbus data type | includes C (Coils), DI (Discrete Inputs), IR (Input Registers) and HR (Holding Registers). |
| Addr             | Modbus register address.                                     |
| .BIT             | optional, Refers to a specific bit of a certain address, with a range from 0 to 15. |

​     Address examples:

| address  example | comment                                      |
| ---------------- | -------------------------------------------- |
| C1.1             | Coils, register address 1, BIT 1             |
| DI2.1            | Discrete Inputs, register address 2, BIT 1   |
| IR1              | Input Registers, register address 1          |
| HR5.2            | Holding Registers, register address 5, BIT 2 |

 

(2) Siemens S7

​    Address description:

| Item           | Description                                                  |
| -------------- | ------------------------------------------------------------ |
| Address format | `AREA ADDRESS[.BIT][.LEN]`                                   |
| AREA ADDRESS   | includes I, O/Q, F/M, T, C, DB.                              |
| .BIT:          | optional, Refers to a specific bit of a certain address, with a range from 0 to 7. |
| .LEN           | When the data type is string, this is a required field that indicates the string length. |

  Address examples:

| address  example | comment                                                      |
| ---------------- | ------------------------------------------------------------ |
| I0               | I Area, address 0                                            |
| O2               | O Area, address 2                                            |
| T7               | T Area, address 7                                            |
| DB10.DBW10       | In the 10th data block, the starting data word is 10.        |
| F2.1             | F Area, address 2, bit 1                                     |
| DB1.DBW12.20     | In the 1st data block, the starting data word is 12, with a string length of 20. |

 

(3) CNC

​    You can enter the addresses of macro variables,  or use built-in system functions.

​    macro variable address examples:

​    200  

​    300 



​    built-in system function addresses:

| address                    |                         usage                         | data type |
| :------------------------- | :---------------------------------------------------: | :-------: |
| cnc_id                     |                        CNC ID                         |  String   |
| cnc_type                   |                   machine tool type                   |  String   |
| cnc_version                |                      CNC version                      |  String   |
| cnc_pathnum                |                    number of path                     |   Int32   |
| cnc_pathname               |                     name of path                      |  String   |
| cnc_spindlenum             |                   number of spindle                   |   Int32   |
| cnc_spindlename            |                    name of spindle                    |  String   |
| cnc_maxesnum               |              number of servo motor axis               |   Int32   |
| cnc_maxesname              |               name of servo motor axis                |  String   |
| cnc_maxistype              |               type of servo motor axis                |  String   |
| cnc_mode                   |              CNC current operation mode               |  String   |
| cnc_runstatus              |              CNC current running status               |  String   |
| cnc_mainproname            | main program name of the current processing execution |  String   |
| cnc_subproname             |  subprogram name of the current processing execution  |  String   |
| cnc_current_nc_instruction |       CNC current numerical control instruction       |   Int32   |
| cnc_single_block           |           number of numerical control block           |   Int32   |
| cnc_alarmnum               |                     alarm number                      |   Int32   |
| cnc_alarminfo              |                   alarm information                   |  String   |
| cnc_products               |                   number of product                   |   Int32   |
| cnc_actsspeed              |                 actual spindle speed                  |   Int32   |
| cnc_srate                  |                     spindle rate                      |   Int32   |
| cnc_sratio                 |                     spindle ratio                     |   Int32   |
| cnc_sload                  |                     spindle load                      |   Int32   |
| cnc_setsspeed              |                   set spindle speed                   |   Int32   |
| cnc_setsrate               |                   set spindle rate                    |   Int32   |
| cnc_actfspeed              |                   actual feed speed                   |   Int32   |
| cnc_frate                  |                       feed rate                       |   Int32   |
| cnc_fload                  |                    feed shaft load                    |   Int32   |
| cnc_setfspeed              |                    set feed speed                     |   Int32   |
| cnc_setfrate               |                     set feed rate                     |   Int32   |
| cnc_mecpos                 |                  mechanical position                  |  String   |
| cnc_relpos                 |                   relative position                   |  String   |
| cnc_respos                 |                   residual position                   |  String   |
| cnc_abspos                 |                   absolute position                   |  String   |
| cnc_toolradiusnum          |            tool radius compensation number            |   Int32   |
| cnc_tool_life              |                       tool life                       |   Int32   |
| cnc_toolnum                |                      tool number                      |   Int32   |
| cnc_runtime                |                     running time                      |  String   |
| cnc_remtime                |                    remaining time                     |  String   |

​    

(4) OPC UA

| Item           | Description                                                  |
| -------------- | ------------------------------------------------------------ |
| Address format | `{data point’s namespace index}`.`{data point’s Indentifier} ` |

![image-20240924182755173](.\img\opcua-demo.png)

Address examples:

   2.inrevo/daee5392/group1/test01

  2.inrevo/daee5392/group1/test02



(5) OPC DA

| Item           | Description                                                  |
| -------------- | ------------------------------------------------------------ |
| Address format | [DevicePath].[GroupName1].[GroupName2]...[GroupNameN].[TagName] |

![image-20240924182908986](.\img\opcda-demo.png)

   Address example:

   group1.group1-1.tag1



(6) Virtual Point

Prefix addresses with "virtual_" to create virtual points.

Address examples:

virtual_temperature

virtual_product

virtual_testname

​       

##### Supported Formulas

The calculation formulas supported by this system are listed below:

###### for real points only

| name        | formula                                | Description                                                  |
| ----------- | -------------------------------------- | ------------------------------------------------------------ |
| Linear      | linear(k, b)                           | return (this point value)*k + b                              |
| Absolute    | abs()                                  | Returns absolute value of the input                          |
| Add         | add(pointid2, pointid3, pointid4, ...) | addition operator placed among point values (includes this point value), returning the sum. |
| Subtract    | sub(pointid2)                          | this point value - pointid2.value, Subtraction operator placed between two point values, returning the difference. |
| Multiply    | mul(pointid2)                          | (this point value) * pointid2.value,  multiplication operator placed between two point values, returning the result. |
| Divide      | div(pointid2)                          | (this point value) / pointid2.value, division operator placed between two point values, returning the result. |
| LOG         | log()                                  | Returns the base 10 logarithm of a point value.              |
| LOGN        | logn(N)                                | Returns the base logn of a point value.                      |
| Square Root | sqrt()                                 | Returns the square root of a point value.                    |

 

formula examples:

| formula  example | comment                  |
| ---------------- | ------------------------ |
| linear(5.6, 8)   | k is 5.6, and b is 8.    |
| add(7d0439ed)    | 7d0439ed is a point’s id |

 

###### for virtual points only

| name        | formula                                  | Description                                                  |
| ----------- | ---------------------------------------- | ------------------------------------------------------------ |
| Linear      | linear_v(pointId, k, b)                  | return (pointId.value)*k + b                                 |
| Add         | add_v(pointid1, pointid2, pointid3, ...) | addition operator placed among point values, returning the sum. |
| Subtract    | sub_v(pointid1, pointid2)                | pointid1.value - pointid2.value, Subtraction operator placed between two point values, returning the difference. |
| Multiply    | mul_v(pointid1, pointid2)                | (pointid1.value) * (pointid2.value),  multiplication operator placed between two point values, returning the result. |
| Divide      | div_v(pointid1, pointid2)                | (pointid1.value) / (pointid2.value), division operator placed between two point values, returning the result. |
| LOG         | log_v(pointId)                           | Returns the base 10 logarithm of a point value.              |
| LOGN        | logn_v(pointId, N)                       | Returns the base logn of a point value                       |
| Square Root | sqrt_v(pointId)                          | Returns the square root of a point value.                    |

 

formula examples:

| formula  example           | comment                                         |
| -------------------------- | ----------------------------------------------- |
| linear_v(7d0439ed, 5.6, 8) | 7d0439ed is a point’s id, k is 5.6, and b is 8. |
| add_v(7d0439ed, f80e359e)  | 7d0439ed and f80e359e are point ids.            |

​        

### Add Point

On the points page, click Add to create a new point.

![image-20240924184057889](.\img\add-point.png)

​    

### Import Points

You can import an Excel file containing points' information to create them in bulk. 

First, export the Excel template (step 1), fill in the necessary information, and then import the file (step 2).

![image-20240924184258943](.\img\import-points.png)

Note: 

(1) Keep only the header row and remove any old point information if it is present in the Excel template.

(2) You do not need to fill in the point_id. An example is shown in the figure below. 

![image-20240924184349881](.\img\import-points-demo.png)

(3) Each Excel file must not exceed 20 MB in size and must have no more than 5,000 rows (excluding headers).

​    

