---
sidebar_position: 6
---

# Data Vista

Data Vista is a no-code web user interface tool. You can use Data Vista to present real-time and historical data of data points in custom charts, graphs, and dashboards without any coding, to build and deploy web-based automation solutions.

​    

## Create a Project

Log in to the Inrevo IOT node (or navigate from the Inrevo IOT monitor side) using your account. In the sidebar, select Data Vista / Projects to enter the Data View module. You will see the following page：

![project-1](./img/project-1.png)

You will notice that there are no projects under the Data View module, so you need to create a project first. Click "Create Project," and a popup will appear for creating a project：

![project-2](./img/project-2.png)

Enter the project name and click the "Save" button. You have successfully created a project.

![project-3](./img/project-3.png)

## Create a Screen

The project has been created, and now you need to create a screen under the project.

Expand the project, and you will see a "Create Screen" button. Click "Create Screen," and a popup will appear for creating a Screen:

![project-4](./img/project-4.png)

![project-5](./img/project-5.png)

Enter the Screen name and click the "Save" button. You have successfully created a Screen.

​    

## Decorate your Screen

After creating the screen, you can decorate your screen page by dragging and dropping various components and setting their parameters.

First, click on the screen you want to decorate or modify, then click Edit.

![image-20240926160944760](.\img\edit-screen.png)



Then, from the toolbox on the right, click and choose the component you want to use.

![image-20240926161450787](.\img\component-pick.png)

Finally, drag and drop the component to the desired position and size, and set its parameters.

![image-20240926162439467](.\img\component-modify.png)

​    

## View your Screen

After decorating the screen,  you can view the result by  click "View" button.

![image-20240926163327970](.\img\screen-view.png)

​    



## Detailed Usage Instructions

For more detailed usage instructions, please refer to [Data Vista Function](/docs/reference/DataVistaFunction/operator/project).

​    



​    

