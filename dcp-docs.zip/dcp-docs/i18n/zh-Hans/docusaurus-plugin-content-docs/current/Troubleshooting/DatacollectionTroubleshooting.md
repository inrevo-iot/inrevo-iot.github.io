---
sidebar_position: 2
displayed_sidebar: tutorialSidebar_zh_hans
---

# 数据采集故障排查

根据[数据采集](/docs/Qickstart/DataCollection)完成驱动、点位组和数据点位的配置后，如果数据采集不正常，您可以通过[数据查询](/docs/Qickstart/DataNavigation#数据查询)页面查看数据点位的状态(质量)。

| Status(Quality) Code | 描述                       | 解决方法                                 |
| -------------------- | -------------------------- | ---------------------------------------- |
| 192                  | normal                     | -                                        |
| 400                  | execution error            | 检测设备是否正常运行。                   |
| 404                  | socket error               | 检测驱动参数是否正确，设备是否正常运行。 |
| 501                  | serializable extract error | 请参考设备手册配置正确的点位地址。       |
| 502                  | serializable param empty   | 请配置正确数据点位参数。                 |
| 503                  | address is not writable    | 请参考设备手册配置可写入数据的点位地址。 |
| 504                  | param type not supported   | 请参考设备手册配置正确的点位数据类型。   |

