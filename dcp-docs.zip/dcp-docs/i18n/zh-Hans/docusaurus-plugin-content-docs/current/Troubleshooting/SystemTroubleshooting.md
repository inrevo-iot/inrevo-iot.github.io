---
sidebar_position: 1
displayed_sidebar: tutorialSidebar_zh_hans
---

# 系统故障排查

## 无法访问Inrevo IOT Web问题

一般情况下，您可以使用安装Inrevo IOT Node / Monitor的机器或计算机的网络IP地址和端口(默认为51000/52000)从浏览器连接到Inrevo IOT Node / Monitor。

If you can not access the Inrevo IOT Web UI:

如果您无法访问Inrevo IOT Web:

首先，检查Inrevo IOT node/monitor进程状态，查看Inrevo IOT系统是否正常运行。

`windows:`

`使用任务管理器检查相关任务(inrevoi -iot-node/ inrevoi -iot-monitor)是否正常`



`linux:`

`systemctl status inrevo-node`

`systemctl status inrevo-monitor`



`docker:`

`docker ps | grep inrevo`



如果相关进程运行异常，检查端口是否被占用，请参考[端口需求](/docs/Qickstart/SystemRequirements#端口需求)。

如果相关进程正常，请检查相关端口是否被防火墙允许通过。
