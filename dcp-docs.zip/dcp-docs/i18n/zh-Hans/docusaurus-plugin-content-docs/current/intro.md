---
sidebar_position: 1
displayed_sidebar: tutorialSidebar_zh_hans
---

# 概述

Inrevo IoT系统可以从各种工业来源采集数据，包括CNC、PLC、DCS、智能仪表和机器人，根据自定义要求处理数据，并支持各种类型的数据应用。

Inrevo IoT系统支持两种不同的使用场景：单体模式和远程监控模式。在单体模式下，只有一个数据节点；而在远程监控模式下，有多个数据节点和一个监控节点。

![standalone](.\img\standalone.png)

<center>
单体模式
</center>




![monitoring](.\img\monitoring.png)

<center>
远程监控模式
</center>

在单体模式下，系统支持本地数据收集和数据访问。

在远程监控模式下，您可以远程管理和控制每个数据节点以收集数据，数据节点会将数据同步到监控端以供应用访问。



## 产品特点

使用 Inrevo IoT 系统，您可以执行以下操作：

- 从各种工业设备收集数据。
- 使用自定义计算公式处理收集的数据。
- 支持将点位的实时数据和历史数据存储在各种数据库中。
- 根据数据点位的实时值配置监控条件。当预设条件满足时，触发告警通知。
- 无需任何编码即可在自定义图表、图形和仪表板中展示点位的实时数据和历史数据。
- 可以在 Windows、Linux 或 Docker 上运行，并支持 x86、x64、arm 和 arm64 架构。



## 常见问题

请参见 [FAQ](./FAQ.md).

​     



   
