---
sidebar_position: 5
displayed_sidebar: tutorialSidebar_zh_hans
---

# 数据导航

一旦设备的数据被成功收集，您就可以通过各种方式查询和访问它。

​    

## 数据查询

在 Data Query / Points 页面，您可以查询数据点位的实时值。

![image-20240926143329236](.\img\data-query.png)

​    

## OPC UA 服务器

如果启用了，Inrevo IOT系统会启动一个OPC UA服务器，提供数据供第3方接入访问。

Inrevo IOT数据节点上的OPC UA服务器只提供该节点收集的数据。Inrevo IOT监控节点上的OPC UA服务器提供连接到该监控节点的所有数据节点采集的数据。

参见 [OPC UA Server](./AccesstheWebUI#opc-ua-server) 页面获取OPC UA服务器的连接参数.

您可以使用OPC UA客户端或通过编程方式连接到本系统的OPC UA服务器并检索数据。

Endpoint Url 格式为: `opc.tcp://{ip}:{ua server port}/inrevo`

例如，假设运行本系统的机器或计算机的IP地址为192.168.101.150，您设置的OPC UA服务端口为53530，则endpoint Url为:

opc.tcp://192.168.101.150:53530/inrevo

![image-20240926143643132](.\img\opcua-connect-demo.png)

After successfully connecting, you can browse the data. 

连接成功后，您可以浏览数据。

数据以以下格式组织:

`inrevo/{node id}/{group name}/{point name}`

![image-20240926143809322](.\img\opcua-browser-data.png)

​    

## 数据库

数据点位的实时和历史数据（如果启用了）已保存到您选择的数据库服务器，数据库名称设置为inrevodata，里面主要有如下表所示3个数据表。

| Table/Measurement |         Usage          |
| :---------------: | :--------------------: |
|       data        | 存储数据点位的实时数据 |
|   data_history    | 存储数据点位的历史数据 |
|   alarm_record    |    存储告警记录数据    |

参考 [Database](./AccesstheWebUI#数据库) 页面获取数据库连接参数。

Inrevo IOT数据节点使用的数据库只提供该节点收集的数据。Inrevo IOT监控节点使用的数据库提供连接到该监控节点的所有数据节点采集的数据。

您可以使用数据库客户端或通过编程方式连接到该系统使用的数据库服务器并检索数据。

​    

## 数据视图

Data Vista是一个无代码的网页用户界面工具。

使用Data Vista，您可以在自定义图表、图形和仪表板中呈现数据点位的实时和历史数据，而无需任何编码，从而简化了可视化数据应用程序的创建。

参考 [Data Vista](./DataVista) 来使用它.

​    

