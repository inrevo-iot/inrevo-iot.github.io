---
sidebar_position: 2
displayed_sidebar: tutorialSidebar_zh_hans
---

# 安装

Inrevo IOT系统可部署在Windows、Linux或Docker平台上，支持x86、x64、arm和arm64架构。



## Windows 安装

*注意:仅支持Windows 64位(在AMD64上)*

### 下载

下载 [inrevo-iot-node-xxx-setup-x64](https://drive.google.com/file/d/10WxNCkKxgZ4RPI_7fXrkR-d97XB3mT6y/view?usp=sharing) (数据节点) 或 [inrevo-iot-monitor-xxx-setup-x64](https://drive.google.com/file/d/10YC93Qi2MA-HDFffxLnnJTcd8-YN7BTq/view?usp=sharing) (监控节点).



### 安装

运行 inrevo-iot-xxx-setup-x64.exe 并按照屏幕上的说明完成安装。



### 升级

你需要先卸载原版本，再重新执行新版本的安装动作。



## Linux 安装

### 下载

根据您的CPU体系结构下载相应的安装包。

[node_x64](https://drive.google.com/file/d/10YKbS0jlW3IFJyzB9QuvR1P1BaH6QdCQ/view?usp=sharing)

[node_x86](https://drive.google.com/file/d/10bq1khvqyckgqFs_QjKHS0ok1mdpmzEj/view?usp=sharing)

[node_arm64](https://drive.google.com/file/d/10d87T4LU026cD71XOXV_wCt6-Hlcwdzr/view?usp=sharing)

[node_arm32](https://drive.google.com/file/d/10cgozAyepm19ghm6AwxhhSWN0_kns2Bv/view?usp=sharing)

 

[monitor_x64](https://drive.google.com/file/d/10lKY9Id9EZaTGsZY6F1Uk-SE9Pzd0TWe/view?usp=sharing)

[monitor_x86](https://drive.google.com/file/d/10n2HJaSItQUORWmyaB83WieVLl_icbs5/view?usp=sharing)

[monitor_arm64](https://drive.google.com/file/d/10kD7jtv167-hSH-hufriQTRbWfPA1res/view?usp=sharing)

[monitor_arm32](https://drive.google.com/file/d/10ifP-facmxnFPm6YvK8-VV5oF2rN-wpp/view?usp=sharing)



### 安装

解压安装包，然后参阅软件包中的说明文件进行安装。



### 升级

解压安装包，然后参阅软件包中的说明文件进行升级。



## Docker 安装

Inrevo IOT 系统能够在Docker容器中运行。

*注意:仅支持64位Linux(在AMD64或ARM64上)*

### 前置条件

1. 安装 [Docker Engine 20.10+](https://docs.docker.com/engine/install/) 
2. 安装 [Docker Compose 2.27+](https://github.com/docker/compose/releases) 



### 下载

根据您的CPU架构下载相应的安装脚本包。

[node_x64](https://drive.google.com/file/d/1-I3l7fcEsKNt02MXBcUvLmfbj9lni_dj/view?usp=sharing)

[node_arm64](https://drive.google.com/file/d/1-MV1EsL_MD_odaFslFNkgBUSoldkpshJ/view?usp=sharing)

 

[monitor_x64](https://drive.google.com/file/d/1-Y308K_RMUzfrmOzibw9RKrED_ylTPEB/view?usp=sharing)

[monitor_arm64](https://drive.google.com/file/d/1-h2BUx4YG6IWOa7s_1SNUcDUA9uyHwDj/view?usp=sharing)



### 安装

解压安装脚本包，然后在脚本包所在路径运行如下命令进行安装：

`docker-compose up -d` 



### 升级

在原版本脚本包所在路径运行如下动作进行升级：

(1) 修改docker-compose.yaml中image版本号

(2) 关闭原版本，运行

​      `docker-compose down`

(3）启动新版本，运行

​    `docker-compose up -d` 

