---
sidebar_position: 4
displayed_sidebar: tutorialSidebar_zh_hans
---

# 数据采集

您可以在Inrevo IOT数据节点页面上配置数据采集。配置数据采集的过程包括:

(1) 设置设备驱动.

(2) 创建一个数据点位组.

(3) 设置数据点位.



## 设备驱动

每台设备都有唯一的连接信息，包括IP、端口、通信方式和协议。设备驱动程序与物理设备相关联。在采集数据前，需要根据设备连接信息配置设备驱动参数。

目前支持的驱动类型有Modbus、Siemens S7、CNC (Fanuc和Mitsubishi)、OPC UA和OPC DA。

![image-20240924174423694](.\img\drivers.png)

​    

### 驱动介绍

#### Modbus

##### 术语解释

| 术语              | 描述                                                         |
| :---------------- | :----------------------------------------------------------- |
| Slave ID          | MODBUS Slave ID 是MODBUS网络中从设备的唯一标识符。           |
| Transmission mode | 指MODBUS中用于通信的模式，包括RTU (Remote Terminal Unit)、TCP(Transmission Control Protocol)和ASCII (American Standard Code for Information Interchange)三种模式。 |
| Word Swap         | 指在数据传输或存储过程中改变多个字（通常是16位、32位或64位）之间的顺序。 |
| Byte Swap         | 字节交换是指在数据传输或存储过程中改变字（通常是16位、32位或64位）内字节的顺序。 |
| Serial port       | 串行端口是用于按顺序传输数据的通信接口。在Windows中，串行端口名称通常以“COM”开头，如COM1、COM2等。这些串行端口内置于计算机中，并通过主板的接口连接。在Linux中，串口名称以“/dev/ttyS”开头，如/dev/ ttys0、/dev/ ttys1等。 |



##### Modbus TCP 参数示例

![image-20240924180539194](.\img\modbus-tcp.png)



##### Modbus RTU 参数示例

![image-20240924180648745](.\img\modbus-rtu.png)



##### Modbus ASCII 参数示例

MODBUS ASCII 会在未来版本中支持。

​    

#### Siemens S7

##### 术语解释

| 术语           | 描述                                                         |
| -------------- | ------------------------------------------------------------ |
| Processor type | 目前支持的西门子PLC型号有:S7-200、S7-200SMART、S7-300、S7-400、S7-1200、S7-1500。 |

 

##### Siemens S7 参数示例

![image-20240924180937494](.\img\s7.png)

​    

#### CNC

##### 术语解释

| Term | Description                                                  |
| ---- | ------------------------------------------------------------ |
| Type | 目前支持的CNC类型包括发那科(0i-MODEL F Plus, 30i/31i/32i/35i-MODEL)和三菱(M800/M80, M700V/ M70V和E70)。 |

***注意：当前版本不支持ARM架构下运行Fanuc驱动。***

##### CNC 参数示例

![image-20240924181114442](.\img\cnc.png)

​    

#### OPC DA

##### 术语解释

| 术语        | 描述                                                         |
| ----------- | ------------------------------------------------------------ |
| Domain      | OPC DA服务器所在机器的计算机名。也可以设置为服务器计算机的IP地址。 |
| Server name | OPC程序名。                                                  |
| Username    | 用户名为具有DCOM权限的Windows用户名。The username is the Windows user name with DCOM permissions. |



##### OPC DA 参数示例

![image-20240926142414152](.\img\opcda_client.png)

​    

#### OPC UA

##### 术语解释

| 术语                  | Description                                                  |
| --------------------- | ------------------------------------------------------------ |
| Server url            | OPC UA 服务器的Endpoint Url，格式为 `opc.tcp://ipaddress:port/{servername}` |
| Authentication method | 认证方式支持匿名和用户帐号两种认证方式。                     |
| Security mode         | 指定义在通信期间如何保护消息的安全设置。包括None、Sign和SignAndEncrypt。 |
| Security policy       | 定义了用于保护通信的安全加密算法和设置，包括None、Basic128Rsa15、Basic256、Basic256Sha256、Aes128_Sha256_RsaOaep 和 Aes256_Sha256_RsaPss等。 |



##### OPC UA 参数示例

![image-20240924181435426](.\img\opcua-client.png)

​    

### 创建驱动 

在Device Drivers / Drivers 页面，单击“Add”，创建新的驱动。

![image-20240924181604613](.\img\add-driver.png)



### 导入驱动

您可以导入包含驱动信息的Excel文件，以便批量创建驱动。

首先，导出Excel模板(步骤1)，填写必要的信息，然后导入文件(步骤2)。

![image-20240924181700519](.\img\import-drivers.png)



 *注意：* 

*(1) 仅保留标题行，并删除Excel模板中存在的任何旧的驱动信息。*

*(2) 无需填写driver_id。下图显示了一个示例。* 

![image-20240924181856786](.\img\import-drivers-demo.png)

*(3) 每个Excel文件的大小不能超过20mb。*

​    

## 数据点位

数据点位是在系统中测量、收集或监控的具体位置或数据项，常用于工业自动化、监控和控制系统中。

您也可以创建没有连接到实际设备的虚拟点位，可以根据其他实际点位进行计算得到其值(参见[公式部分](DataCollection#对于虚拟点位))。

点位组是为了便于管理而分组在一起的点的集合。

配置完设备驱动后，您就可以为数据采集配置数据点位了。



### 点位组

您可以创建、删除或修改点位组。

![image-20240924182154138](.\img\group-1.png)

![image-20240924182248614](.\img\group-2.png)

​    

### 点位介绍

#### 术语解释

| 术语    | 描述                                                         |
| ------- | ------------------------------------------------------------ |
| Address | 在工业数据中，点位地址Address是指设备或系统中存储或访问数据的特定位置或标识符。详见 [点位地址要求](DataCollection#点位地址要求). |
| Type    | 指与系统中特定点或测量相关联的特定类型的数据。在Inrevo IOT系统中，数据类型包括string、bool、byte、uint16、int16、uint32、int32、int64、float32、float64。 |
| Unit    | 数据单位是指用于一个数据点位的特定测量单位，如米、摄氏度或公斤。 |
| Period  | 数据采集周期(或间隔)，单位为秒，是指从一个数据点位采集或采样数据的时间间隔。最小周期(或间隔)为1秒。 |
| Formula | 计算公式是指用于从一个或多个数据点位计算或导出值的方程或表达式。详见 [支持的公式](DataCollection#支持的公式) |
| Alarm   | 告警是一种指示特定情况或事件发生的信号或通知，通常用于提醒操作人员或系统采取行动。<br/>告警类型包括“阈值(Threshold)”和“相等(Equal)”。<br/>告警等级包括 1，2，3，4 和 5，其中1表式最高等级。<br/>当选择阈值(Threshold)告警类型时，可设置高-高(high high)、高(high)、低(low)、低-低(low low)四种阈值。<br/>与“高(high)”阈值相比，“高-高(high high)”阈值表示更严重的情况。“高-高(high high)”阈值通常设置在“高”阈值之上，表示情况危急。<br/>同样，在比较较低值时，“低-低(low low)”表示比“低(low)”更严重的情况。.<br/>如果选择相等(Equal)告警类型，则可以设置要比较的值，当该值与数据点位的值相等时触发告警。 |



##### 点位地址要求

*注意:对于每个设备驱动，点位地址格式有特定的要求。*

(1) Modbus

​    地址描述：

| 单项             | 描述                                                         |
| ---------------- | ------------------------------------------------------------ |
| Address format   | `{modbus data type}{Addr}[.BIT]`                             |
| modbus data type | 包括 C (线圈Coils), DI (离散输入Discrete Inputs), IR (输入寄存器Input Registers) 和 HR (存储寄存器Holding Registers)。 |
| Addr             | Modbus寄存器地址。                                           |
| .BIT             | 可选的，表示某个地址的特定位，取值范围为0 ~ 15。             |

​     地址示例：

| 地址示例 | 解释                                          |
| -------- | --------------------------------------------- |
| C1.1     | 线圈Coils, 寄存器地址 1, 位1                  |
| DI2.1    | 离散输入Discrete Inputs，寄存器地址1, 位1     |
| IR1      | 输入寄存器Input Registers，寄存器地址 1       |
| HR5.2    | 存储寄存器Holding Registers，寄存器地址5, 位2 |

 

(2) Siemens S7

​    地址描述：

| 单项           | 描述                                                 |
| -------------- | ---------------------------------------------------- |
| Address format | `AREA ADDRESS[.BIT][.LEN]`                           |
| AREA ADDRESS   | 包括 I, O/Q, F/M, T, C, DB.                          |
| .BIT:          | 可选的，表示某个地址的特定位，取值范围为0 ~ 7。      |
| .LEN           | 当数据类型为字符串时，这是指示字符串长度的必填字段。 |

   地址示例：

| 地址示例     | 解释                                         |
| ------------ | -------------------------------------------- |
| I0           | I 区域，地址为 0                             |
| O2           | O 区域，地址为 2                             |
| T7           | T 区域，地址为 7                             |
| DB10.DBW10   | 10 数据块中，起始数据字为 10                 |
| F2.1         | F 区域，地址为2，第 1 位                     |
| DB1.DBW12.20 | 1 数据块中，起始数据字为 12，字符串长度为 20 |

 

(3) CNC

   您可以输入宏变量的地址，或者使用内置的系统函数。

​    宏变量的地址示例：

​    200  

​    300 



​    内置的系统函数:

| 地址                       |           用途            | 数据类型 |
| :------------------------- | :-----------------------: | :------: |
| cnc_id                     |          CNC ID           |  String  |
| cnc_type                   |       说明机床类型        |  String  |
| cnc_version                |          CNC版本          |  String  |
| cnc_pathnum                |         通道数量          |  Int32   |
| cnc_pathname               |         通道名称          |  String  |
| cnc_spindlenum             |         主轴数量          |  Int32   |
| cnc_spindlename            |         主轴名称          |  String  |
| cnc_maxesnum               |        伺服轴轴数         |  Int32   |
| cnc_maxesname              |        伺服轴名称         |  String  |
| cnc_maxistype              |        伺服轴类型         |  String  |
| cnc_mode                   |     当前所处操作模式      |  String  |
| cnc_runstatus              |     当前设备运行状态      |  String  |
| cnc_mainproname            | cnc当前加工执行的主程序号 |  String  |
| cnc_subproname             |         子程序名          |  String  |
| cnc_current_nc_instruction |        当前程序行         |  Int32   |
| cnc_single_block           |        程序段编号         |  Int32   |
| cnc_alarmnum               |          报警号           |  Int32   |
| cnc_alarminfo              |         报警信息          |  String  |
| cnc_products               |        cnc生产件数        |  Int32   |
| cnc_actsspeed              |       实际主轴转速        |  Int32   |
| cnc_srate                  |         主轴速率          |  Int32   |
| cnc_sratio                 |         主轴倍率          |  Int32   |
| cnc_sload                  |         主轴负载          |  Int32   |
| cnc_setsspeed              |       设定主轴转速        |  Int32   |
| cnc_setsrate               |       设定主轴速率        |  Int32   |
| cnc_actfspeed              |       实际进给速度        |  Int32   |
| cnc_frate                  |         进给速率          |  Int32   |
| cnc_fload                  |        进给轴负载         |  Int32   |
| cnc_setfspeed              |       设定进给转速        |  Int32   |
| cnc_setfrate               |       设定进给速率        |  Int32   |
| cnc_mecpos                 |         机械坐标          |  String  |
| cnc_relpos                 |         相对坐标          |  String  |
| cnc_respos                 |         剩余坐标          |  String  |
| cnc_abspos                 |         绝对位置          |  String  |
| cnc_toolradiusnum          |     刀具半径补偿编号      |  Int32   |
| cnc_tool_life              |         刀具寿命          |  Int32   |
| cnc_toolnum                |     当前使用的刀具号      |  Int32   |
| cnc_runtime                |       设备运行时间        |  String  |
| cnc_remtime                |         剩余时间          |  String  |

​    

(4) OPC UA

| 单项           | 描述                                                         |
| -------------- | ------------------------------------------------------------ |
| Address format | `{data point’s namespace index}`.`{data point’s Indentifier} ` |

![image-20240924182755173](.\img\opcua-demo.png)

地址示例：

   2.inrevo/daee5392/group1/test01

  2.inrevo/daee5392/group1/test02



(5) OPC DA

| 单项           | 描述                                                         |
| -------------- | ------------------------------------------------------------ |
| Address format | [DevicePath].[GroupName1].[GroupName2]...[GroupNameN].[TagName] |

![image-20240924182908986](.\img\opcda-demo.png)

  地址示例：

   group1.group1-1.tag1



(6) 虚拟点位

你可以在点位地址前加前缀“virtual_”用来创建虚拟点。

地址示例：

virtual_temperature

virtual_product

virtual_testname

​       

##### 支持的公式

本系统支持的计算公式如下：

###### 对于实际点位

| 名称        | 公式                                   | 描述                                     |
| ----------- | -------------------------------------- | ---------------------------------------- |
| Linear      | linear(k, b)                           | 返回 (本点位值)*k + b                    |
| Absolute    | abs()                                  | 返回本点位绝对值                         |
| Add         | add(pointid2, pointid3, pointid4, ...) | 返回参数所列各点位值(包括本点位)的总和。 |
| Subtract    | sub(pointid2)                          | 返回本点位减去pointid2值的差。           |
| Multiply    | mul(pointid2)                          | 返回本点位和pointid2值的乘积。           |
| Divide      | div(pointid2)                          | 返回本点位 除以 pointid2值的结果。       |
| LOG         | log()                                  | 返回点位值的以10为基数的对数。           |
| LOGN        | logn(N)                                | 返回点位值的以N为基数的对数。            |
| Square Root | sqrt()                                 | 返回点位值的平方根。                     |

 

公式示例：

| 公式示例       | 解释              |
| -------------- | ----------------- |
| linear(5.6, 8) | k为5.6, b为8.     |
| add(7d0439ed)  | 7d0439ed 是点位ID |

 

###### 对于虚拟点位

| 名称        | 公式                                     | 描述                                   |
| ----------- | ---------------------------------------- | -------------------------------------- |
| Linear      | linear_v(pointId, k, b)                  | 返回 (pointId点位当前值)*k + b         |
| Add         | add_v(pointid1, pointid2, pointid3, ...) | 返回参数所列各点位值的总和。           |
| Subtract    | sub_v(pointid1, pointid2)                | 返回pointid1值减去pointid2值的差。     |
| Multiply    | mul_v(pointid1, pointid2)                | 返回pointid1值和pointid2值的乘积。     |
| Divide      | div_v(pointid1, pointid2)                | 返回pointId1值 除以 pointid2值的结果。 |
| LOG         | log_v(pointId)                           | 返回pointId点位值的以10为基数的对数。  |
| LOGN        | logn_v(pointId, N)                       | 返回pointId点位值的以N为基数的对数。   |
| Square Root | sqrt_v(pointId)                          | 返回pointId点位值的平方根。            |

 

公式示例：

| 公式示例                   | 解释                              |
| -------------------------- | --------------------------------- |
| linear_v(7d0439ed, 5.6, 8) | 7d0439ed 是点位ID，k为5.6，b为8。 |
| add_v(7d0439ed, f80e359e)  | 7d0439ed  和 f80e359e 是点位ID。  |

​        

### 创建点位

在Data Points / Points页面， 点击"Add"新建点位。

![image-20240924184057889](.\img\add-point.png)

​    

### 导入点位

您可以导入包含点位信息的Excel文件，以便批量创建数据点位。

首先，导出Excel模板(步骤1)，填写必要的信息，然后导入文件(步骤2)。

![image-20240924184258943](.\img\import-points.png)

*注意：* 

*(1) 仅保留标题行，并删除Excel模板中存在的任何旧的点位信息。*

*(2) 无需填写point_id，下图显示了一个示例。*

![image-20240924184349881](.\img\import-points-demo.png)

*(3) 每个Excel文件的大小不得超过20mb，并且不得超过5,000行(不包括表头)。*

​    

