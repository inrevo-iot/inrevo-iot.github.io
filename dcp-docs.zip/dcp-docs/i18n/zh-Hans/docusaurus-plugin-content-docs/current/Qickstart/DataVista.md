---
sidebar_position: 6
displayed_sidebar: tutorialSidebar_zh_hans
---

# 数据视图

Data Vista 是一个无代码的网页用户界面工具。您可以使用 Data Vista 以自定义图表、图形和仪表板的形式展示数据点的实时数据和历史数据，无需任何编码，即可构建和部署基于 Web 的自动化解决方案。

​    

## 创建项目

登录系统,并在侧边栏中选中Data Vista / Projects，进入数据视图模块。您将看到下面的页面：

![project-1](./img/project-1.png)

您可以看到数据视图模块下还没有项目，此时需要您先创建一个项目。单击“创建项目”，您将看到一个创建项目的弹窗：

![project-2](./img/project-2.png)

填入项目名，点击“保存”按钮，您就创建成功了一个项目。

![project-3](./img/project-3.png)

## 创建视图

项目已经创建完成了，接下来就需要在项目下面创建视图了。

展开项目，您可以看到一个“创建视图”的按钮，点击“创建视图”，您将看到一个创建视图的弹窗：

![project-4](./img/project-4.png)

![project-5](./img/project-5.png)

填入视图名称，点击“保存”按钮，您就创建成功了一个视图。

​    

## 装饰视图

在创建视图后，您可以通过拖放各种组件并设置其参数来装饰您的视图页面。

首先，点击您想要装饰或修改的视图页面，然后点击编辑Edit。

![image-20240926160944760](.\img\edit-screen.png)



然后，从右侧的工具箱中，点击并选择您想要使用的组件

![image-20240926161450787](.\img\component-pick.png)

最后，将组件拖放到所需的位置并调整其大小，然后设置其参数。

![image-20240926162439467](.\img\component-modify.png)

​    

## 查看视图

装饰视图页面后，您可以通过点击“View”按钮来查看结果。

![image-20240926163327970](.\img\screen-view.png)

​    



## 详细使用说明

对于更详细的使用说明，请参阅 [数据视图功能](/docs/reference/DataVistaFunction/operator/project).

​    



​    

