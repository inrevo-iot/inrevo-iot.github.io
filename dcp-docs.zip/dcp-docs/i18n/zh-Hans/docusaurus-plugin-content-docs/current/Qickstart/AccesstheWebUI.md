---
sidebar_position: 3
displayed_sidebar: tutorialSidebar_zh_hans
---

# 访问网页界面

Inrevo IOT系统安装成功后，您可以通过浏览器访问Web UI。



## 数据节点

### 通过浏览器访问

您可以使用安装了数据节点的机器或计算机的网络IP地址和端口(默认为51000)从浏览器连接到Inrevo IOT 数据节点。

例如，假设您的机器或计算机的IP地址为192.168.101.150，则在浏览器中输入

 http://192.168.101.150:51000

以访问web界面。



### 登录数据节点网页

![image-20240924165247998](.\img\login.png)



Inrevo IOT 数据节点默认管理员账号为:

| 用户名 | 密码   |
| ------ | ------ |
| admin  | inrevo |

稍后您可以修改密码。

​    

### 系统设置

登录后，您可以进行用户管理、修改系统参数、激活系统等操作。

   ![image-20240924174258467](.\img\settings.png)



#### 用户管理

您可以创建、删除和修改用户。

   ![image-20240924171453751](.\img\user.png)

| 安全组        | 权限                                                         |
| ------------- | ------------------------------------------------------------ |
| Administrator | 可访问所有功能                                               |
| Operator      | 可以访问 Device drivers, Data Points, Data Query, Data Vista. |
| User          | 可以访问 Data Query, Data Vista.                             |



#### 选项

##### 设备驱动

最大驱动数 - 设置该节点可创建的最大驱动个数。

*注意:建议该数值不要超过机器CPU核数的两倍。*

​    

##### 历史

启用 - 是否存储历史数据。

最大保留时间 - 设置历史数据(包括告警数据)的最大保留天数。

​    

##### 数据库

您可以选择一种数据库并输入连接参数，用于存储数据点位的实时和历史数据。

目前支持的数据库类型有SQLite、MariaDB、MySQL、SQL Server、PostgreSQL、Oracle和InfluxDB。

1. SQLite

![image-20240924165843852](.\img\sqlite.png)

在您的机器或计算机上指定一个sqlite数据库路径，Inrevo IOT系统将自动创建sqlite数据库。

*注意：SQLite仅用于测试目的，不应在生产环境中使用。*



2. MariaDB, MySQL, SQL Server, PostgreSQL, Oracle, and InfluxDB

   你需要事先安装准备好拟选定的数据库。

   如图所示，输入数据库IP、端口、用户名和密码等。

   ![image-20240924170025291](.\img\db.png)

   

   *注意：* 

    *(1) 数据库帐户必须具有创建数据库和执行CRUD(创建、读取、更新、删除)操作的权限。*

    *(2) 各类数据库版本要求如下:*

   *MariaDB 10.2+*

   *MySQL 5.7+*

   *PostgreSQL  9.5+*
   
   *SqlServer 2012+*
   
   *Oracle 11g+*
   
   *InfluxDB v2.0+*
   
   ​       

##### OPC UA 服务器

如果启用了，Inrevo IOT会启动一个OPC UA Server，提供数据供第3方接入访问。您可以设置该OPC UA服务器的相关参数。

![image-20240924172840255](.\img\opcua.png)

​       

##### 连接监控节点

Inrevo IOT数据节点可连接Inrevo IOT监控节点。

![image-20240924170504734](.\img\connect2monitor.png)

关键参数描述：

**Enable**: 是否启用连接

**Unidirectional**: 如果选中，表示单向传输，即监控节点只能从该数据节点读取数据；否则，表示双向传输，即监控节点对该数据节点既可读又可写。

输入要连接的Inrevo IOT监控节点的IP、端口、用户名和密码。

##### 转发到云端

Inrevo IOT node can forward (if Enabled) OT data to Cloud. The currently supported target types are Kafka, MQTT and AWS IoT.

![image-20241121181354649](.\img\cloud.png)

关键参数描述：

**Target**: 数据接收目的地。当前版本支持Kafka、MQTT和AWS IoT。

**Buffer Data**: 当网络连接到云端失败时，Inrevo IoT 节点会将 OT 数据缓冲到您选择的数据库中。当网络恢复时，Inrevo IoT 节点会立即恢复传输在网络中断期间收集的所有数据到云端平台，确保云端数据的完整性和准确性。此参数决定了数据缓存的天数。0 表示不缓存。

**Server Address**:  IP:Port或URL。 格式参考下面的示例：

|       Target       |                   Server Address                   |
| :----------------: | :------------------------------------------------: |
|       Kafka        | 192.168.3.3:9092,192.168.3.4:9092,192.168.3.5:9092 |
|        MQTT        |                  192.168.3.3:1883                  |
| MQTT (SSL enabled) |                  192.168.3.3:8883                  |
|      AWS IoT       |    xxx-ats.iot.cn-northwest-1.amazonaws.com.cn     |



​     

#### 通知

您可以配置告警通知，当点位数据满足预定义条件并触发告警时，告警通知将通过电子邮件或SMS发送。

##### 邮件通知

![image-20240924170735814](.\img\email.png)

要启用E-Mail作为通知类型，您需要根据您的电子邮件服务器提供商网站上的说明为您的电子邮件帐户启用SMTP服务，并获取授权码用作密码。

邮件服务器的格式是server_address:port，下面是一些示例:

| email server format       | to enable SMTP service                                       |
| ------------------------- | ------------------------------------------------------------ |
| smtp.gmail.com:587        | 开启[SMTP](https://help.accredible.com/s/article/smtp-setup-in-gmail-inbox?language=en_US) |
| smtp-mail.outlook.com:587 | 开启[SMTP](https://support.microsoft.com/en-us/office/pop-imap-and-smtp-settings-for-outlook-com-d088b986-291d-42b8-9564-9c414e2aa040) ，开启[双重验证](https://support.microsoft.com/zh-cn/account-billing/%E5%A6%82%E4%BD%95%E5%AF%B9%E4%BD%A0%E7%9A%84-microsoft-%E5%B8%90%E6%88%B7%E4%BD%BF%E7%94%A8%E5%8F%8C%E9%87%8D%E9%AA%8C%E8%AF%81-c7910146-672f-01e9-50a0-93b4585e7eb4) 并设置[Oauth2认证](https://learn.microsoft.com/zh-cn/entra/identity-platform/v2-oauth2-auth-code-flow)。并且将tenant, client_id, client_secret以tenant:client_id:client_secret格式拼起来作为密码。 |

​    

##### 短信通知

![image-20240924171814648](.\img\sms.png)

要启用SMS作为通知类型，您需要使用 [Twilio service](https://www.twilio.com).

输入您的Twilio电话号码，帐户SID，身份验证令牌和接收电话号码。

​     

#### 许可证

您需要一个许可证才能激活系统并使用完整的服务。没有有效的许可证，将无法进行数据采集(包括添加驱动、配置点、数据存储等)。

复制许可代码（license code）并将其发送给Inrevo销售团队以获取许可密钥(license key)。然后输入此许可密钥，点击“激活”即可激活Inrevo IOT系统。

![image-20240924172021611](.\img\license.png)



## 监控节点

### 通过浏览器访问

您可以使用安装了监控节点的机器或计算机的网络IP地址和端口(默认为52000)从浏览器连接到Inrevo IOT 监控节点。

例如，假设您的机器或计算机的IP地址为192.168.101.160，则在浏览器中输入

 http://192.168.101.160:52000

以访问web界面。

​    

### 登录监控节点网页

![image-20240924172328517](.\img\monitor.png)

Inrevo IOT监控节点默认管理员帐号为：

| 用户名 | 密码   |
| ------ | ------ |
| super  | inrevo |

稍后您可以修改密码。

​    

### 系统设置

登录后，您可以修改系统参数和激活本系统。

#### 选项

##### 历史

启用 - 是否存储历史数据。

最大保留时间 - 设置历史数据(包括告警数据)的最大保留天数。

​    

##### 数据库

您可以选择一种数据库并输入连接参数，用于存储数据点位的实时和历史数据。

目前支持的数据库类型有SQLite、MariaDB、MySQL、SQL Server、PostgreSQL、Oracle和InfluxDB.。

1. SQLite

![image-20240924165843852](.\img\sqlite.png)

在您的机器或计算机上指定一个sqlite数据库路径，Inrevo IOT系统将自动创建sqlite数据库。

*注意：SQLite仅用于测试目的，不应在生产环境中使用。*



2. MariaDB, MySQL, SQL Server, PostgreSQL, Oracle, and InfluxDB.

   你需要事先安装准备好拟选定的数据库。

   如图所示，输入数据库IP、端口、用户名和密码等。

   ![image-20240924170025291](.\img\db.png)

   

   *注意：* 

    *(1) 数据库帐户必须具有创建数据库和执行CRUD(创建、读取、更新、删除)操作的权限。*

    *(2) 各类数据库版本要求如下:*

   *MariaDB 10.2+*

   *MySQL 5.7+*

   *PostgreSQL  9.5+*

   *SqlServer 2012+*

   *Oracle 11g+*
   
   *InfluxDB v2.0+*
   
   ​       

##### OPC UA Server

如果启用了，Inrevo IOT会启动一个OPC UA Server，提供数据供第3方接入访问。您可以设置该OPC UA服务器的相关参数。

![image-20240924172840255](.\img\opcua.png)

​    

​     

##### 监控节点认证

您可以设置Inrevo IOT监控节点连接的账户(用户名和密码)。

![image-20240925130755583](.\img\monitor-auth.png)

​    

#### 许可证

您需要一个许可证才能激活系统并使用完整的服务。没有有效的许可证，将无法连接和监控各数据节点。

复制许可代码（license code）并将其发送给Inrevo销售团队以获取许可密钥(license key)。然后输入此许可密钥，点击“激活”即可激活Inrevo IOT系统。

![image-20240924173425212](.\img\monitor-lic.png)

​    

### 数据节点管理

一旦Inrevo IOT数据节点连接到Inrevo IOT 监控节点，您就可以管理数据节点，包括更新数据节点信息和访问数据节点的web界面。

![image-20240924173537669](.\img\nodes.png)

​    

