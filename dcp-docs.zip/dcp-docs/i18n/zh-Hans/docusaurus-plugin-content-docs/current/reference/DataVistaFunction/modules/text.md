---
sidebar_position: 2
displayed_sidebar: tutorialSidebar_zh_hans
---

# 文本

组件允许您在视图中添加静态文字，或关联点位数据并展示。

<div className="img">![text-1](./img/text-1.png)</div>

## 特征

| 属性     | 类型      | 描述    |
| -------- | ------- | ------- |
| Text     | Text     | 文本文字 |

#### 文本属性设置

<div className="img">![text-2](./img/text-2.png)</div>

#### 关联动态点位数据

点击点位ICON <span className="img-top">![img-6](./img/img-6.png)</span> , 打开点位关联窗口，对组件设置关联点位。

<div className="img">![text-3](./img/text-3.png)</div>