---
sidebar_position: 6
displayed_sidebar: tutorialSidebar_zh_hans
---

# 实时数据

该组件用于点位的实时数据以表格的形式展示

<div className="img">![realtime-1](./img/realtime-1.png)</div>

## 特征

| 属性     | 类型      | 描述    |
| -------- | ------- | ------- |
| Tags      | Tag Array   |  组件关联的点位列表 |


## 设置

<div className="img">![realtime-2](./img/realtime-2.png)</div>

点击输入框 , 打开点位关联窗口，对组件设置关联点位。点击add Option 按钮，添加关联的点位。

## 表格特征

| 属性     | 类型      | 描述    |
| -------- | ------- | ------- |
| font color (header)      | Color   |  表格头部的文字颜色 |
| bg color (header)        | Color   |  表格头部的背景颜色 |
| font color (row)         | Color   |  表格内容的文字颜色 |
| bg color (row)           | Color   |  表格行的背景颜色 |
| grid color (row)         | Color   |  表格行的边框颜色 |

## 表格参数设置

<div className="img">![realtime-3](./img/realtime-3.png)</div>
