---
sidebar_position: 1
displayed_sidebar: tutorialSidebar_zh_hans
---

# 项目

## 创建项目

在侧边栏中选中Data Vista / Projects，进入数据视图模块（如果是master节点，需先跳转到node节点上）。您将看到下面的页面：

![project-1](./img/project-1.png)

您可以看到数据视图模块下还没有项目，此时需要您先创建一个项目。单击“创建项目”，您将看到一个创建项目的弹窗：

![project-2](./img/project-2.png)

填入项目名，点击“保存”按钮，您就创建成功了一个项目。

![project-3](./img/project-3.png)


## 删除项目

项目命后面有个删除的图标，点击图标可对其进行删除操作。