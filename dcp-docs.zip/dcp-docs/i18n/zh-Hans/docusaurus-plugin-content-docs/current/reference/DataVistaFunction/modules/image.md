---
sidebar_position: 1
displayed_sidebar: tutorialSidebar_zh_hans
---

# 图片

允许您制定静态或动态图片，在视图中显示。

<div className="img">![img-1](./img/img-1.png)</div>

## 特征

| 属性     | 类型      | 描述    |
| -------- | ------- | ------- |
| Default Media | Img Path          | 默认的图片路径 |
| size          | Select Options    | 图片的尺寸：原有尺寸、拉伸、保持比列拉伸 |
| repeat        | Select Options    | 图片的重复方式：不重复、水平轴重复、垂直轴重复、两个轴都重复 |

#### 图像属性设置

<div className="img">![img-3](./img/img-3.png)</div>

点击灰色方框，将打开[文件资源选择器](/docs/reference/DataVistaFunction/media)，选择使用的默认图像。

<div className="img">![img-5](./img/img-5.png)</div>

选择图片后，可以对其设置size和repeat属性。

#### 动态图片设置

点击点位ICON <span className="img-top">![img-6](./img/img-6.png)</span> , 打开图片点位关联窗口，对组件设置关联点位。

<div className="img">![img-7](./img/img-7.png)</div>