---
sidebar_position: 16
displayed_sidebar: tutorialSidebar_zh_hans
---

# 转换器

该组件允许您创建一个转换器组件，允许您在“开”和“关”的状态之间来回切换，且支持您定义组件的变更[事件](/docs/reference/DataVistaFunction/conf#事件)。

<div className="img">![switch-1](./img/switch-1.png)</div>


## 特征

| 属性     | 类型      | 描述    |
| -------- | ------- | ------- |
| defaultColor    | Color     | 组件默认的颜色 |
| activeColor     | Color     | 组件在“开”状态下的颜色 |

## 配置
<div className="img">![switch-2](./img/switch-2.png)</div>


<p></p>
其他特征请参见[组件共有配置](/docs/reference/DataVistaFunction/conf)。