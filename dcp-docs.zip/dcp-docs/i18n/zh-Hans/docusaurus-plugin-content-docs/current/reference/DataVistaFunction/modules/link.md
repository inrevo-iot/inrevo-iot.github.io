---
sidebar_position: 3
displayed_sidebar: tutorialSidebar_zh_hans
---

# 链接

链接允许您制定静态或动态链接，让用户点击并将 Web 浏览器页面导航到另一个目的地。链接可以是外部的，链接到其他网站或页面，也可以是内部的，链接到特定的项目屏幕。这对于构建导航非常有用

<div className="img">![link-1](./img/link-1.png)</div>

## 特征

| 属性     | 类型      | 描述    |
| -------- | ------- | ------- |
| Url      | Text     | 链接地址 |
| Text     | Text     | 链接文字 |
| Font     | Font Options    | 字体相关配置 |
