---
sidebar_position: 14
displayed_sidebar: tutorialSidebar_zh_hans
---

# 下拉框

该组件允许您创建一个下拉框组件，且支持您定义组件的变更[事件](/docs/reference/DataVistaFunction/conf#事件)。

<div className="img">![select-1](./img/select-1.png)</div>
<div className="img">![select-3](./img/select-3.png)</div>


## 特征

| 属性     | 类型      | 描述    |
| -------- | ------- | ------- |
| value     | Text     | 默认选中的具体事项或根据点位状态设置动态的具体事项 |
| options   | check Options     | 下拉框的具体事项 |

## 配置
<div className="img">![select-2](./img/select-2.png)</div>

<p></p>
其他特征请参见[组件共有配置](/docs/reference/DataVistaFunction/conf)。