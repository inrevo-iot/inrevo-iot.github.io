---
sidebar_position: 10
displayed_sidebar: tutorialSidebar_zh_hans
---

# 按钮

该组件用于提供标准的点击事件，供用户操作，具体支持事件参见[“组件共有配置”](/docs/reference/DataVistaFunction/conf#事件)。
<p></p>
组件允许您添加静态文字，或关联点位数据并展示。

<div className="img">![button-1](./img/button-1.png)</div>


## 特征

| 属性     | 类型      | 描述    |
| -------- | ------- | ------- |
| Text     | Text     | 文本文字 |

其他特征，如：[边距](/docs/reference/DataVistaFunction/conf#边距)、[字体配置](/docs/reference/DataVistaFunction/conf#字体配置) 等等，请参见组件共有配置。