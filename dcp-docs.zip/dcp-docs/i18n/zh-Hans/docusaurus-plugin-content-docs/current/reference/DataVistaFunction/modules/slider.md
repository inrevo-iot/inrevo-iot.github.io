---
sidebar_position: 17
displayed_sidebar: tutorialSidebar_zh_hans
---

# 滑块

该组件允许您创建一个进度条组件，允许您在一个范围内调整所需展示的值，且支持您定义组件的变更[事件](/docs/reference/DataVistaFunction/conf#事件)。

<div className="img">![slider-1](./img/slider-1.png)</div>


## 特征

| 属性     | 类型      | 描述    |
| -------- | ------- | ------- |
| value    | number     | 组件默认展示的值，可关联点位数据，作为默认数据展示 |
| min      | number     | 组件的最小值 |
| max      | number     | 组件的最大值 |
| step     | number     | 组件拖动时的步长 |
| base color     | Color     | 组件的背景色 |
| arc color      | Color     | 组件内部的填充色 |
| font color     | Color     | 组件字体的颜色 |
| duration       | boolean     | 组件展示的方向，默认为横向，取消勾选则垂直展示 |

## 配置
<div className="img">![slider-2](./img/slider-2.png)</div>


<p></p>
其他特征请参见[组件共有配置](/docs/reference/DataVistaFunction/conf)。