---
sidebar_position: 12
displayed_sidebar: tutorialSidebar_zh_hans
---

# 检查清单

该组件允许您创建一张检查清单，且支持您定义检查清单的变更[事件](/docs/reference/DataVistaFunction/conf#事件)。

<div className="img">![checklist-1](./img/checklist-1.png)</div>


## 特征

| 属性     | 类型      | 描述    |
| -------- | ------- | ------- |
| value     | Text     | 默认选中的具体事项或根据点位状态设置动态的具体事项，多个值需用“,”分隔 |
| options   | check Options     | 检查清单的具体事项 |

## 配置
<div className="img">![checklist-2](./img/checklist-2.png)</div>

<p></p>
其他特征请参见[组件共有配置](/docs/reference/DataVistaFunction/conf)。