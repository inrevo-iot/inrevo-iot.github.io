---
sidebar_position: 9
displayed_sidebar: tutorialSidebar_zh_hans
---

# 趋势图

该组件用于展示最近一段时间内的数据趋于信息。

<div className="img">![trend-1](./img/trend-1.png)</div>

<p></p>
左上角可以勾选显示历史数据，勾选后再可以看到一个日期范围选择器。选择您需要查询的历史范围，以便在下图中显示。

<div className="img">![trend-3](./img/trend-3.png)</div>

<p></p>
点击右上角“播放”按钮，组件将以时序的形式展示点位数据

## 表格特征

| 属性     | 类型      | 描述    |
| -------- | ------- | ------- |
| Tags         | Tag Array   |  组件关联的点位列表 |
| Tag Config   | Trend Option Array  |  每个点位的趋势图配置信息 |
| - line color | Color     |  折线的颜色 |
| - fill       | boolean   |  折线下方与轴线直接的区域是否填充颜色 |
| - y-min      | number    |  Y轴的最小值 |
| - y-max      | number    |  Y轴的最大值 |
| - y-step     | number    |  Y轴的刻度间隔 |
| - y-axis     | Check Options   |  Y轴在图表的位置，左或者右 |
| - show y-axis| boolean   |  是否显示Y轴 |

## 关联点位及显示设置

<div className="img">![trend-2](./img/trend-2.png)</div>
