---
sidebar_position: 7
displayed_sidebar: tutorialSidebar_zh_hans
---

# 数据表格

该组件用于展示所选点位的某一时间范围内的历史数据

<div className="img">![data-1](./img/data-1.png)</div>

## 特征

| 属性     | 类型      | 描述    |
| -------- | ------- | ------- |
| Tags      | Tag Array   |  组件关联的点位列表 |


## 设置

<div className="img">![data-2](./img/data-2.png)</div>

点击输入框 , 打开点位关联窗口，对组件设置关联点位。点击add Option 按钮，添加关联的点位。

## 表格特征

| 属性     | 类型      | 描述    |
| -------- | ------- | ------- |
| font color (header)      | Color   |  表格头部的文字颜色 |
| bg color (header)        | Color   |  表格头部的背景颜色 |
| font color (row)         | Color   |  表格内容的文字颜色 |
| bg color (row)           | Color   |  表格行的背景颜色 |
| grid color (row)         | Color   |  表格行的边框颜色 |

## 表格参数设置

<div className="img">![realtime-3](./img/realtime-3.png)</div>


## 表格列说明

| 属性     | 类型      | 描述    |
| -------- | ------- | ------- |
| Data Time      | time   |  采集点位数据的时间 |
| 其他列      | Tag   |  选择展示的点位对应时间的数值 |


## 过滤

可通过组件右上角的日期范围，筛选特定时间范围内的数据进行展示。