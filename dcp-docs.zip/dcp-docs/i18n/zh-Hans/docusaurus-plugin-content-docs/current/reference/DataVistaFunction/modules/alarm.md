---
sidebar_position: 8
displayed_sidebar: tutorialSidebar_zh_hans
---

# 报警

该组件用于展示最近一段时间内的报警信息

<div className="img">![alarm-1](./img/alarm-1.png)</div>

## 表格特征

| 属性     | 类型      | 描述    |
| -------- | ------- | ------- |
| font color (header)      | Color   |  表格头部的文字颜色 |
| bg color (header)        | Color   |  表格头部的背景颜色 |
| font color (row)         | Color   |  表格内容的文字颜色 |
| bg color (row)           | Color   |  表格行的背景颜色 |
| grid color (row)         | Color   |  表格行的边框颜色 |
| Level Grid Color         | Color   |  未关闭的不同报警等级的行背景色 |

## 表格参数设置

<div className="img">![realtime-3](./img/realtime-3.png)</div>

## 报警等级颜色设置

<div className="img">![alarm-2](./img/alarm-2.png)</div>


## 表格列说明

| 属性     | 类型      | 描述    |
| -------- | ------- | ------- |
| Data Time      | time   |  采集点位数据的时间 |
| 其他列      | Tag   |  选择展示的点位对应时间的数值 |


## 过滤

可通过组件左上角的输入框，筛选匹配到的数据进行展示。