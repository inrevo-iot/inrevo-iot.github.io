---
sidebar_position: 5
displayed_sidebar: tutorialSidebar_zh_hans
---

# 比例尺

可关联点位数据，实时更新展示点位信息。

<div className="img">![scale-1](./img/scale-1.png)</div>

## 特征

| 属性     | 类型      | 描述    |
| -------- | ------- | ------- |
| value      | Number   | Tag Value    | 静态数值或点位数值 |
| min        | Number   | 比例尺的最小值 |
| max        | Number   | 比例尺的最大值 |
| arc width  | Number   | 比例尺的宽度 |
| font size  | Number   | 比例尺字体的大小 |
| base color | Color    | 比例尺的背景色 |
| arc color  | Color    | 比例尺的前景色 |
| font color | Color    | 比例尺的字体的颜色 |
| duration | Check Options    | 比例尺的方向：纵向或横向，默认纵向展示 |

## 设置

<div className="img">![scale-2](./img/scale-2.png)</div>

点击value后面的点位ICON <span className="img-top">![img-6](./img/img-6.png)</span> , 打开点位关联窗口，对组件设置关联点位，可实时展示点位值。