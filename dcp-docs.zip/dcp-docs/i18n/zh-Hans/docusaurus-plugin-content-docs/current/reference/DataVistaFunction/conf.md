---
sidebar_position: 3
displayed_sidebar: tutorialSidebar_zh_hans
---

# 组件共有配置

## 位置及大小
配置组件在视图中的位置，及所占区域的大小

<div className="img">![conf-pos](./img/conf-pos.png)</div>

#### 特征

| 属性     | 类型     | 描述    |
| -------- | ------- | ------- |
| x        | number    | 组件距离页面左边的距离 |
| y        | number    | 组件距离页面顶部的距离 |
| width    | number    | 组件的宽度 |
| height   | number    | 组件的高度 |

## 背景色及边框
配置组件的背景色及边框粗细、样式和颜色

<div className="img">![conf-bg](./img/conf-bg.png)</div>

#### 特征

| 属性     | 类型     | 描述    |
| -------- | ------- | ------- |
| color(background)  | color           | 组件的背景色 |
| size               | number          | 组件边框的宽度 |
| style              | select Options  | 组件边框样式的配置 |
| radius             | number          | 组件边框的圆弧角度 |
| color(border)      | number          | 组件边框的颜色 |

## 边距
配置组件的边距

<div className="img">![conf-padding](./img/conf-padding.png)</div>

#### 特征

| 属性     | 类型     | 描述    |
| -------- | ------- | ------- |
| left     | number  | 组件的左边距 |
| right    | number  | 组件的右边距 |
| top      | number  | 组件的上边距 |
| bottom   | number  | 组件的下边距 |

## 字体配置
配置字体相关的属性

<div className="img">![conf-font](./img/conf-font.png)</div>

#### 特征

| 属性     | 类型     | 描述    |
| -------- | ------- | ------- |
| font family     | Select Options  | 字体选项 |
| size            | number          | 字体大小 |
| line-height     | number          | 字体的行高 |
| style           | check Options   | 字体的样式：宽体、斜体、下划线、中划线 |
| align           | check Options   | 字体的对齐方式：左对齐、水平居中、右对齐、置于顶部、垂直居中、置于底部 |
| color           | color           | 字体的颜色 |

## 提醒配置
配置闪烁提醒的参数

<div className="img">![conf-flash](./img/conf-flash.png)</div>

#### 特征

| 属性     | 类型     | 描述    |
| -------- | ------- | ------- |
| enable    | boolean     | 组件是否闪烁 |
| rate      | number      | 闪烁的时长 |
| count     | number      | 闪烁的次数 |

## 事件
配置一些组件的点击或者变化触发的事件

<div className="img">![evt-none](./img/evt-none.png)</div><div className="img">![evt-2](./img/evt-2.png)</div>

#### 特征

| 属性     | 类型     | 描述    |
| -------- | ------- | ------- |
| Action    | Select Options     | 事件类型：无，给点位设置值，跳转到某个视图，跳转到主页，跳转到某个URL |

#### 默认值：无

不触发任何事件

#### 给点位设置值

在Action下方的下拉框中选择Set tag，其次点击Set a tag下方的输入框，将弹出一个点位的选择器，选择一个点位。最后，在最下方的下拉框中，选择一个组件（比如：input组件），则在触发事件时，将会把input组件里的值赋给设置的点位。

步骤1.

<div className="img">![evt-tag-1](./img/evt-tag-1.png)</div>

步骤2.

<div className="img">![evt-tag-2](./img/evt-tag-2.png)</div>
<div className="img">![evt-tag-3](./img/evt-tag-3.png)</div>

步骤3.

<div className="img">![evt-tag-4](./img/evt-tag-4.png)</div>
<div className="img">![evt-tag-5](./img/evt-tag-5.png)</div>

#### 跳转到某个视图

在Action下方的下拉框中选择Go to Screen，其次在Screen下方的下拉框中选择要跳转到的视图

<div className="img">![evt-screen-1](./img/evt-screen-1.png)</div>
<div className="img">![evt-screen-2](./img/evt-screen-2.png)</div>

#### 跳转到主页

在Action下方的下拉框中选择Go Home即可。

<div className="img">![evt-home](./img/evt-home.png)</div>

#### 跳转到某个URL

在Action下方的下拉框中选择Go to URL，其次在URL下方的输入框中，输入要跳转的链接地址

<div className="img">![evt-url](./img/evt-url.png)</div>