---
sidebar_position: 11
displayed_sidebar: tutorialSidebar_zh_hans
---

# 输入框

该组件用于提供标准的文本输入，在事件中可以绑定该组件的值，为其他点位赋值。
<p></p>
组件可以关联点位。进入页面时，如果组件关联了点位，则会加载点位数据，并展示在组件中。但之后如果关联的点位发生变化，组件不会自动更新。如需实时展示点位数据，可使用[文本组件](/docs/reference/DataVistaFunction/modules/text)。
<p></p>
另外，该组件同样支持[变化事件](/docs/reference/DataVistaFunction/conf#事件)，如果输入框里的值发生变更，将触发您绑定的事件。


<div className="img">![input-1](./img/input-1.png)</div>


## 特征

| 属性     | 类型      | 描述    |
| -------- | ------- | ------- |
| Text     | Text     | 文本文字 |

其他特征，如：[边距](/docs/reference/DataVistaFunction/conf#边距)、[字体配置](/docs/reference/DataVistaFunction/conf#字体配置) 等等，请参见组件共有配置。