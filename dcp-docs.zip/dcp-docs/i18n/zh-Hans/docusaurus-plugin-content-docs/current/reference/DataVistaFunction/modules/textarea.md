---
sidebar_position: 15
displayed_sidebar: tutorialSidebar_zh_hans
---

# 文本域

该组件允许您创建一个文本域组件，且支持您定义组件的变更[事件](/docs/reference/DataVistaFunction/conf#事件)。

<div className="img">![textarea-1](./img/textarea-1.png)</div>


## 特征

| 属性     | 类型      | 描述    |
| -------- | ------- | ------- |
| content     | Text     | 支持设置默认的展示文本，且支持根据点位数据配置默认文本 |

## 配置
<div className="img">![textarea-2](./img/textarea-2.png)</div>


#### 关联动态点位数据

点击点位ICON <span className="img-top">![img-6](./img/img-6.png)</span> , 打开点位关联窗口，对组件设置关联点位，并设置对应文本内容。

<p></p>
其他特征请参见[组件共有配置](/docs/reference/DataVistaFunction/conf)。