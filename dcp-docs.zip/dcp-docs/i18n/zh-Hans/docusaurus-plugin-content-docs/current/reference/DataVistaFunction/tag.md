---
sidebar_position: 5
displayed_sidebar: tutorialSidebar_zh_hans
---

# 点位关联

很多组件都可以关联点位，以动态设置一些数据。
其中主要有以下几种类型：
#### 1. 直接关联点位值，如：Text组件、仪表盘、比例尺等等。

<div className="img">![tag-1](./img/tag-1.png)</div>

#### 2. 根据点位值设置文本，如：Link组件、文本域等待。

<div className="img">![tag-3](./img/tag-3.png)</div>

#### 3. 根据点位值设置图片，如：Image组件。

<div className="img">![tag-4](./img/tag-4.png)</div>

## 点位选择器

以上三种点位关联，都需要选择具体点位进行关联，都需要通过下方的点位选择器进行选择点位。

<p>点位选择器左侧显示的点位组，右侧显示的点位组下的点位列表。</p>

<p>列表上方有一个筛选器，可快速筛选需要匹配的点位名。</p>

<div className="img">![tag-2](./img/tag-2.png)</div>
