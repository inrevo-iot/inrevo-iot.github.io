---
sidebar_position: 4
displayed_sidebar: tutorialSidebar_zh_hans
---

# 仪表盘

可关联点位数据，实时更新展示点位信息。

<div className="img">![gauge-1](./img/gauge-1.png)</div>

## 特征

| 属性     | 类型      | 描述    |
| -------- | ------- | ------- |
| value      | Number   | Tag Value    | 静态数值或点位数值 |
| min        | Number   | 仪表盘的起始值 |
| max        | Number   | 仪表盘的结束值 |
| arc width  | Number   | 仪表盘的圆弧的宽度 |
| font size  | Number   | 仪表盘字体的大小 |
| base color | Color    | 仪表盘的背景色 |
| arc color  | Color    | 仪表盘的前景色 |
| font color | Color    | 仪表盘的字体的颜色 |

## 设置

<div className="img">![gauge-2](./img/gauge-2.png)</div>

点击value后面的点位ICON <span className="img-top">![img-6](./img/img-6.png)</span> , 打开点位关联窗口，对组件设置关联点位，可实时展示点位值。