---
sidebar_position: 5
displayed_sidebar: tutorialSidebar_zh_hans
---

# Inrevo IoT System - API Doc



## Common Response Code

| code | description                                                  | schema |
| ---- | ------------------------------------------------------------ | ------ |
| 200  | successful operation                                         | Result |
| 400  | Bad Request, check whether the parameters are correct        |        |
| 401  | Unauthorized, check if there is correct bearer token in header |        |
| 403  | Forbidden,  check if the user has correct authority          |        |
| 404  | Not Found,  check whether the path is correct                |        |
| 415  | Unsupported Media Type                                       |        |
| 500  | Internal Server Error                                        |        |



## User Management




### user login


**url**:`/api/v1/user/login`


**method**:`POST`

**produces**:`application/json`


**consumes**:`application/json`

**Note**:

**Example**:


```javascript
{
  "username": "someuser",
  "password": "123456"
}
```


**Params**:


| name | description | in    | require | type | schema |
| -------- | -------- | ----- | -------- | -------- | ------ |
|loginRequest|LoginRequest|body|true|LoginRequest|LoginRequest|
|&emsp;&emsp;username|user name||true|string||
|&emsp;&emsp;password|password||true|string||


**Status**:


| code | description | schema |
| -------- | -------- | ----- | 
|200|successful operation|Result|
|404|user not found|Result|


**code-200**:


**Response Params**:


| name | description | type | schema |
| -------- | -------- | ----- |----- | 
|success|whether it is successful or not|boolean||
|message|error message|string||
|data|content object|object||


**Response Example**:
```javascript
{
    "success": true,
    "message": null,
    "data": {
        "userId": "ec64ad14",
        "username": "someuser",
        "securityGroup": "User",
        "status": "activated",
        "token": "eyJhbGciOiJIUzI1NiJ9.eyJzZWN1cml0eUdyb3VwIjoiQWRtaW5pc3RyYXRvciIsImV4cCI6MTczMzM4NDEyNSwidXNlcklkIjoiZWM2NGFkMTQiLCJrZXkiOiIwMDkxYzRlMWUwNmE4NDIwYmRhMWI5OTg0MmY3Njk2NzgxZjgxNjc4ZTI5NWU4NDY5NzE4NzJiM2MwNGE0NGI2IiwidXNlcm5hbWUiOiJhZG1pbiJ9.VuT1agy_EExFAtPJbNeD_lHifWWRQ23PJDUHoV0N1Hs",
        "nodeType": "node",
        "nodeId": "e0333fd5"
    }
}
```


**code-404**:


**Response Params**:


| name | description | type | schema |
| -------- | -------- | ----- |----- | 
|success|whether it is successful or not|boolean||
|message|error message|string||
|data|content object|object||


**Response Example**:
```javascript
{
    "success":false,
    "message":"user not found or wrong password",
    "data":null
}
```


### user info

**url**:`/api/v1/user`


**method**:`GET`


**produces**:`application/x-www-form-urlencoded`

**consumes**:`application/json`


**Note**:<p>Get user info by bearer token.</p>



**Params**:


| name | description | in    | require | type | schema |
| -------- | -------- | ----- | -------- | -------- | ------ |
|Authorization|Bearer token for authentication, format is: `Bearer ${token}`|header|true|string||

**Status**:


| code | description | schema |
| -------- | -------- | ----- |
|200|successful operation|Result|


**code-200**:

**Response Params**:


| name | description | type | schema |
| -------- | -------- | ----- |----- | 
|success|whether it is successful or not|boolean||
|message|error message|string||
|data|content object|object||


**Response Example**:
```javascript
{
	"success": true,
	"message": "",
	"data": {
        "userId": "ec64ad14",
        "username": "someuser",
        "securityGroup": "User",
        "status": "activated",
        "token": "eyJhbGciOiJIUzI1NiJ9.eyJzZWN1cml0eUdyb3VwIjoiQWRtaW5pc3RyYXRvciIsImV4cCI6MTczMzM4NDEyNSwidXNlcklkIjoiZWM2NGFkMTQiLCJrZXkiOiIwMDkxYzRlMWUwNmE4NDIwYmRhMWI5OTg0MmY3Njk2NzgxZjgxNjc4ZTI5NWU4NDY5NzE4NzJiM2MwNGE0NGI2IiwidXNlcm5hbWUiOiJhZG1pbiJ9.VuT1agy_EExFAtPJbNeD_lHifWWRQ23PJDUHoV0N1Hs",
        "nodeType": "node"
    }
}
```


### add user

**url**:`/api/v1/user/{nodeId}`


**method**:`POST`

**produces**:`application/json`

**consumes**:`application/json`

**Note**:


**Example**:


```javascript
{
  "username": "user2",
  "password": "123456",
  "securityGroup": "Operator",
  "status": "activated"
}
```


**Params**:


| name                      | description                                                | in     | require | type     | schema   |
| ------------------------- | ---------------------------------------------------------- | ------ | ------- | -------- | -------- |
| Authorization             | Bearer token for authentication, format is: `Bearer ${token}`                            | header | true    | string   |          |
| nodeId                    | node id                                                    | path   | true    | string   |          |
| userInfo                  | UserInfo                                                   | body   | true    | UserInfo | UserInfo |
| &emsp;&emsp;username      | user name                                                  |        | true    | string   |          |
| &emsp;&emsp;password      | password                                                   |        | true    | string   |          |
| &emsp;&emsp;securityGroup | security group, including Administrator, Operator and User |        | true    | string   |          |
| &emsp;&emsp;status        | status, including activated and deactivated                |        | true    | string   |          |


**Status**:


| code | description          | schema |
| ---- | -------------------- | ------ |
| 200  | successful operation | Result |
| 400  | invalid parameters   | Result |


**code-200**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
    "success":true,
    "message":null,
    "data":{
        "userId":"80e6d9ab"
    }
}
```


**code-400**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |

**Response Example**:

```javascript
{
	"success": false,
	"message": "failed to add user.",
	"data": null
}
```


### edit user

**url**:`/api/v1/user/{nodeId}/{userId}`


**method**:`PUT`

**produces**:`application/json`


**consumes**:`application/json`


**Note**:

**Example**:


```javascript
{
  "username": "user2",
  "securityGroup": "User",
  "status": "activated"
}
```


**Params**:


| name                      | description                                                | in     | require | type     | schema   |
| ------------------------- | ---------------------------------------------------------- | ------ | ------- | -------- | -------- |
| Authorization             | Bearer token for authentication, format is: `Bearer ${token}`                            | header | true    | string   |          |
| nodeId                    | node id                                                    | path   | true    | string   |          |
| userId                    | user id                                                    | path   | true    | string   |          |
| userInfo                  | UserInfo                                                   | body   | true    | UserInfo | UserInfo |
| &emsp;&emsp;username      | user name                                                  |        | true    | string   |          |
| &emsp;&emsp;password      | password                                                   |        | true    | string   |          |
| &emsp;&emsp;securityGroup | security group, including Administrator, Operator and User |        | true    | string   |          |
| &emsp;&emsp;status        | status, including activated and deactivated                |        | true    | string   |          |


**Status**:


| code | description          | schema |
| ---- | -------------------- | ------ |
| 200  | successful operation | Result |
| 404  | user not found       | Result |


**code-200**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
    "success":true,
    "message":null,
    "data":{
        "userId":"80e6d9ab"
    }
}
```


**code-404**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
	"success": false,
	"message": "the username does not exist.",
	"data": null
}
```


### change user password

**url**:`/api/v1/user/password`

**method**:`PUT`

**produces**:`application/json`

**consumes**:`application/json`


**Note**:


**Example**:


```javascript
{
  "oriPassword": "123456",
  "newPassword": "654321"
}
```


**Params**:


| name                    | description                                                  | in     | require | type          | schema        |
| ----------------------- | ------------------------------------------------------------ | ------ | ------- | ------------- | ------------- |
| Authorization           | Bearer token for authentication, format is: `Bearer ${token}` | header | true    | string        |               |
| userPasswords           | UserPasswords                                                | body   | true    | UserPasswords | UserPasswords |
| &emsp;&emsp;oriPassword | original password                                            |        | true    | string        |               |
| &emsp;&emsp;newPassword | new password                                                 |        | true    | string        |               |


**Status**:


| code | description          | schema |
| ---- | -------------------- | ------ |
| 200  | successful operation | Result |
| 401  | unauthorized         | Result |


**code-200**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
	"success": true,
	"message": null,
	"data": null
}
```


**code-401**:

**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
	"success": false,
	"message": "change password failed.",
	"data": null
}
```


### query users

**url**:`/api/v1/user/{nodeId}`

**method**:`GET`

**produces**:`multipart/form-data`

**consumes**:`application/json`

**Note**:

**Params**:


| name          | description                                         | in     | require | type           | schema |
| ------------- | --------------------------------------------------- | ------ | ------- | -------------- | ------ |
| Authorization | Bearer token for authentication, format is: `Bearer ${token}`                    | header | true    | string         |        |
| nodeId        | node id                                             | path   | true    | string         |        |
| pageNum       | current page number                                 | query  | false   | integer(int32) |        |
| pageSize      | page size                                           | query  | false   | integer(int32) |        |
| username      | user name                                           | query  | false   | string         |        |
| securityGroup | security group, including activated and deactivated | query  | false   | string         |        |


**Status**:


| code | description          | schema |
| ---- | -------------------- | ------ |
| 200  | successful operation | Result |
| 400  | invalid parameters   | Result |


**code-200**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
    "success": true,
    "message": null,
    "data": {
        "total": 2,
        "pageSize": 2,
        "rows": [
            {
                "userId": "c471edc6",
                "username": "user2",
                "securityGroup": "Operator",
                "status": "activated"
            },
            {
                "userId": "ec64ad14",
                "username": "admin",
                "securityGroup": "Administrator",
                "status": "activated"
            }
        ],
        "pageNum": 1
    }
}
```


**code-400**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
	"success": true,
	"message": null,
	"data": null
}
```


### delete user


**url**:`/api/v1/user/{nodeId}/{userId}`


**method**:`DELETE`


**produces**:`application/x-www-form-urlencoded`


**consumes**:`application/json`


**Note**:


**Params**:


| name          | description                     | in     | require | type   | schema |
| ------------- | ------------------------------- | ------ | ------- | ------ | ------ |
| Authorization | Bearer token for authentication, format is: `Bearer ${token}` | header | true    | string |        |
| nodeId        | node id                         | path   | true    | string |        |
| userId        | user id                         | path   | true    | string |        |


**Status**:


| code | description          | schema |
| ---- | -------------------- | ------ |
| 200  | successful operation | Result |
| 404  | user not found       | Result |


**code-200**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
	"success": true,
	"message": null,
	"data": null
}
```


**code-404**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
	"success": false,
	"message": "user does not exist",
	"data": null
}
```



### delete users


**url**:`/api/v1/user/{nodeId}`


**method**:`DELETE`

**produces**:`application/json`


**consumes**:`application/json`


**Note**:


**Example**:


```javascript
["fca01a35", "c471edc6"]
```


**Params**:


| name          | description                                                  | in     | require | type   | schema |
| ------------- | ------------------------------------------------------------ | ------ | ------- | ------ | ------ |
| Authorization | Bearer token for authentication, format is: `Bearer ${token}` | header | true    | string |        |
| nodeId        | node id                                                      | path   | true    | string |        |
| userIds       | user ids                                                     | body   | true    | array  |        |


**Status**:


| code | description                     | schema |
| ---- | ------------------------------- | ------ |
| 200  | successful operation            | Result |
| 207  | some users failed to be deleted | Result |


**code-200**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
	"success": true,
	"message": null,
	"data": null
}
```


**code-207**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
	"success": false,
	"message": "deleting user [c471edc6] failed",
	"data": { "failedIds": ["c471edc6"]}
}
```


### user logout


**url**:`/api/v1/user/logout`


**method**:`POST`


**produces**:`application/x-www-form-urlencoded`


**consumes**:`application/json`


**Note**:


**Params**:


| name          | description                     | in     | require | type   | schema |
| ------------- | ------------------------------- | ------ | ------- | ------ | ------ |
| Authorization | Bearer token for authentication, format is: `Bearer ${token}` | header | true    | string |        |


**Status**:


| code | description          | schema |
| ---- | -------------------- | ------ |
| 200  | successful operation | Result |
| 401  | unauthorized         | Result |


**code-200**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
	"success": true,
	"message": null,
	"data": null
}
```


**code-401**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
	"success": false,
	"message": "unauthorized",
	"data": {}
}
```

## Options Management


### query settings


**url**:`/api/v1/options/{nodeId}`


**method**:`GET`


**produces**:`application/x-www-form-urlencoded`

**consumes**:`application/json`

**Note**:


**Params**:


| name          | description                     | in     | require | type   | schema |
| ------------- | ------------------------------- | ------ | ------- | ------ | ------ |
| Authorization | Bearer token for authentication, format is: `Bearer ${token}` | header | true    | string |        |
| nodeId        | node id                         | path   | true    | string |        |


**Status**:


| code | description          | schema |
| ---- | -------------------- | ------ |
| 200  | successful operation | Result |
| 400  | invalid parameters   | Result |


**code-200**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
    "success": true,
    "message": null,
    "data": {
        "deviceDrivers": {
            "maximumDriverNumber": 8
        },
        "history": {
            "enable": false,
            "maximumRetentionTime": 2
        },
        "database": {
            "dbType": "MariaDB",
            "host": "192.168.101.39",
            "port": 3306,
            "username": "xxx",
            "password": "yyyyyy"
        },
        "opcUaServer": {
            "enable": false,
            "serverPort": 53530,
            "authentication": "Account",
            "username": "uuuu",
            "password": "aaaa",
            "maximumConnections": 20,
            "modeSignAndEncryptChecked": false,
            "modeSignOnlyChecked": true,
            "modeNoneChecked": true,
            "policyNoneChecked": true,
            "policyBasic128Rsa15Checked": false,
            "policyBasic256Checked": true,
            "policyBasic256Sha256Checked": false,
            "policyAes128_Sha256_RsaOaepChecked": false,
            "policyAes256_Sha256_RsaPssChecked": false
        },
        "connectionToMonitor": {
            "enable": false,
            "unidirectional": false,
            "ip": "192.168.101.150",
            "port": 52000,
            "username": "ooooo",
            "password": "ppppp"
        },
        "forwardToCloud": {
            "enable": false,
            "bufferDays": 0,
            "target": "",
            "serverAddr": "",
            "username": "",
            "password": "",
            "securityProtocol": "",
            "mechanism": "",
            "sslTruststoreLocation": "",
            "sslTruststorePassword": "",
            "sslKeystoreLocation": "",
            "sslKeystorePassword": "",
            "sslKeyPassword": "",
            "oauthTokenEndpointUri": "",
            "oauthClientId": "",
            "oauthClientSecret": "",
            "oauthScope": "",
            "oauthClaimSub": "",
            "saslKerberosClientConf": "",
            "saslKerberosServiceName": "",
            "keyTab": "",
            "principal": "",
            "compressiontype": "",
            "clientId": "",
            "qos": 0,
            "ssl": false,
            "certificatePemLocation": "",
            "privatePemKey": "",
            "caPemLocation": ""
        }
    }
}
```


**code-400**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
	"success": false,
	"message": "invalid parameters",
	"data": null
}
```


### edit settings


**url**:`/api/v1/options/{nodeId}`


**method**:`PUT`

**produces**:`application/json`


**consumes**:`application/json`


**Note**:


**Example**:


```javascript
{
  "deviceDrivers": {
    "maximumDriverNumber": 8
  },
  "history": {
    "enable": true,
    "maximumRetentionTime": 7
  },
  "database": {
    "dbType": "MariaDB",
    "host": "192.168.111.48",
    "port": 3306,
    "username": "uuuuu",
    "password": "pppp"
  },
  "opcUaServer": {
    "enable": true,
    "serverPort": 35350,
    "authentication": "Anonymous",
    "username": "",
    "password": "",
    "maximumConnections": 10,
    "modeSignAndEncryptChecked": true,
    "modeSignOnlyChecked": true,
    "modeNoneChecked": true,
    "policyNoneChecked": true,
    "policyBasic128Rsa15Checked": true,
    "policyBasic256Checked": true,
    "policyBasic256Sha256Checked": true,
    "policyAes128_Sha256_RsaOaepChecked": true,
    "policyAes256_Sha256_RsaPssChecked": true
  },
  "connectionToMonitor": {
    "enable": false,
    "unidirectional": true,
    "ip": "",
    "port": 0,
    "username": "",
    "password": ""
  },
  "forwardToCloud": {
    "enable": false,
    "bufferDays": 0,
    "target": "",
    "serverAddr": "",
    "username": "",
    "password": "",
    "securityProtocol": "",
    "mechanism": "",
    "sslTruststoreLocation": "",
    "sslTruststorePassword": "",
    "sslKeystoreLocation": "",
    "sslKeystorePassword": "",
    "sslKeyPassword": "",
    "oauthClaimSub": "",
    "saslKerberosClientConf": "",
    "saslKerberosServiceName": "",
    "keyTab": "",
    "principal": "",
    "compressiontype": "",
    "clientId": "",
    "qos": 0,
    "ssl": true,
    "certificatePemLocation": "",
    "privatePemKey": "",
    "caPemLocation": ""
  }
}
```


**Params**:


| name                                                       | description                                                  | in     | require | type                | schema              |
| ---------------------------------------------------------- | ------------------------------------------------------------ | ------ | ------- | ------------------- | ------------------- |
| Authorization                                              | Bearer token for authentication, format is: `Bearer ${token}`                              | header | true    | string              |                     |
| nodeId                                                     | node id                                                      | path   | true    | string              |                     |
| optionsInfo                                                | OptionsInfo                                                  | body   | true    | OptionsInfo         | OptionsInfo         |
| &emsp;&emsp;deviceDrivers                                  |                                                              |        | false   | DeviceDrivers       | DeviceDrivers       |
| &emsp;&emsp;&emsp;&emsp;maximumDriverNumber                | maximum driver number                                        |        | false   | integer(int32)      |                     |
| &emsp;&emsp;history                                        |                                                              |        | false   | History             | History             |
| &emsp;&emsp;&emsp;&emsp;enable                             | whether to store historical data                             |        | false   | boolean             |                     |
| &emsp;&emsp;&emsp;&emsp;maximumRetentionTime               | maximum retention time                                       |        | false   | integer(int32)      |                     |
| &emsp;&emsp;database                                       |                                                              |        | false   | Database            | Database            |
| &emsp;&emsp;&emsp;&emsp;dbType                             | database type, including SQLite,MariaDB,MySQL,MS SQL Server,PostgreSQL,Oracle,InfluxDB |        | true    | string              |                     |
| &emsp;&emsp;&emsp;&emsp;host                               | host of database                                             |        | false   | string              |                     |
| &emsp;&emsp;&emsp;&emsp;port                               | port of database                                             |        | false   | integer(int32)      |                     |
| &emsp;&emsp;&emsp;&emsp;username                           | username of database                                         |        | false   | string              |                     |
| &emsp;&emsp;&emsp;&emsp;password                           | password of database                                         |        | false   | string              |                     |
| &emsp;&emsp;&emsp;&emsp;filePath                           | file path of SQLite                                          |        | false   | string              |                     |
| &emsp;&emsp;&emsp;&emsp;serviceName                        | service name of Oracle                                       |        | false   | string              |                     |
| &emsp;&emsp;&emsp;&emsp;org                                | organization of InfluxDB                                     |        | false   | string              |                     |
| &emsp;&emsp;&emsp;&emsp;bucket                             | bucket of InfluxDB                                           |        | false   | string              |                     |
| &emsp;&emsp;&emsp;&emsp;token                              | token of InfluxDB                                            |        | false   | string              |                     |
| &emsp;&emsp;opcUaServer                                    |                                                              |        | false   | OpcUaServer         | OpcUaServer         |
| &emsp;&emsp;&emsp;&emsp;enable                             | whether to enable OPC UA Server                              |        | true    | boolean             |                     |
| &emsp;&emsp;&emsp;&emsp;serverPort                         | server port of OPC UA Server                                 |        | true    | integer(int32)      |                     |
| &emsp;&emsp;&emsp;&emsp;authentication                     | authentication method, including Account and Anonymous       |        | true    | string              |                     |
| &emsp;&emsp;&emsp;&emsp;username                           | username of OPC UA Server                                    |        | false   | string              |                     |
| &emsp;&emsp;&emsp;&emsp;password                           | password of OPC UA Server                                    |        | false   | string              |                     |
| &emsp;&emsp;&emsp;&emsp;maximumConnections                 | maximum connections                                          |        | true    | integer(int32)      |                     |
| &emsp;&emsp;&emsp;&emsp;modeSignAndEncryptChecked          | whether to choose SignAndEncrypt mode                        |        | false   | boolean             |                     |
| &emsp;&emsp;&emsp;&emsp;modeSignOnlyChecked                | whether to choose SignOnly mode                              |        | false   | boolean             |                     |
| &emsp;&emsp;&emsp;&emsp;modeNoneChecked                    | whether to choose None mode                                  |        | false   | boolean             |                     |
| &emsp;&emsp;&emsp;&emsp;policyNoneChecked                  | whether to choose None policy                                |        | false   | boolean             |                     |
| &emsp;&emsp;&emsp;&emsp;policyBasic128Rsa15Checked         | whether to choose Basic128Rsa15 policy                       |        | false   | boolean             |                     |
| &emsp;&emsp;&emsp;&emsp;policyBasic256Checked              | whether to choose Basic256 policy                            |        | false   | boolean             |                     |
| &emsp;&emsp;&emsp;&emsp;policyBasic256Sha256Checked        | whether to choose Basic256Sha256 policy                      |        | false   | boolean             |                     |
| &emsp;&emsp;&emsp;&emsp;policyAes128_Sha256_RsaOaepChecked | whether to choose Aes128_Sha256_RsaOaep policy               |        | false   | boolean             |                     |
| &emsp;&emsp;&emsp;&emsp;policyAes256_Sha256_RsaPssChecked  | whether to choose Aes256_Sha256_RsaPss policy                |        | false   | boolean             |                     |
| &emsp;&emsp;connectionToMonitor                            |                                                              |        | false   | ConnectionToMonitor | ConnectionToMonitor |
| &emsp;&emsp;&emsp;&emsp;enable                             | whether to enable connection to monitor                      |        | true    | boolean             |                     |
| &emsp;&emsp;&emsp;&emsp;unidirectional                     | whether to choose unidirectional transmission to monitor     |        | true    | boolean             |                     |
| &emsp;&emsp;&emsp;&emsp;ip                                 | ip of monitor                                                |        | true    | string              |                     |
| &emsp;&emsp;&emsp;&emsp;port                               | port of monitor                                              |        | true    | integer(int32)      |                     |
| &emsp;&emsp;&emsp;&emsp;username                           | username of monitor                                          |        | true    | string              |                     |
| &emsp;&emsp;&emsp;&emsp;password                           | password of monitor                                          |        | true    | string              |                     |
| &emsp;&emsp;forwardToCloud                                 |                                                              |        | false   | ForwardToCloud      | ForwardToCloud      |
| &emsp;&emsp;&emsp;&emsp;enable                             | whether to enable forward data to cloud                      |        | true    | boolean             |                     |
| &emsp;&emsp;&emsp;&emsp;bufferDays                         | buffer data in Days if cloud network is abnormal             |        | true    | integer(int32)      |                     |
| &emsp;&emsp;&emsp;&emsp;target                             | data receiving destination, including Kafka, MQTT and AWS IoT |        | true    | string              |                     |
| &emsp;&emsp;&emsp;&emsp;serverAddr                         | server address of target                                     |        | true    | string              |                     |
| &emsp;&emsp;&emsp;&emsp;username                           | username of target                                           |        | false   | string              |                     |
| &emsp;&emsp;&emsp;&emsp;password                           | password of target                                           |        | false   | string              |                     |
| &emsp;&emsp;&emsp;&emsp;securityProtocol                   | security protocol of Kafka                                   |        | false   | string              |                     |
| &emsp;&emsp;&emsp;&emsp;mechanism                          | security mechanism of Kafka                                  |        | false   | string              |                     |
| &emsp;&emsp;&emsp;&emsp;sslTruststoreLocation              | ssl truststore location                                      |        | false   | string              |                     |
| &emsp;&emsp;&emsp;&emsp;sslTruststorePassword              | ssl truststore password                                      |        | false   | string              |                     |
| &emsp;&emsp;&emsp;&emsp;sslKeystoreLocation                | ssl keystore location                                        |        | false   | string              |                     |
| &emsp;&emsp;&emsp;&emsp;sslKeystorePassword                | ssl keystore password                                        |        | false   | string              |                     |
| &emsp;&emsp;&emsp;&emsp;sslKeyPassword                     | (private) key password                                       |        | false   | string              |                     |
| &emsp;&emsp;&emsp;&emsp;oauthClaimSub                      | oauth claim sub                                              |        | false   | string              |                     |
| &emsp;&emsp;&emsp;&emsp;saslKerberosClientConf             | kerberos client conf location                                |        | false   | string              |                     |
| &emsp;&emsp;&emsp;&emsp;saslKerberosServiceName            | kerberos service name                                        |        | false   | string              |                     |
| &emsp;&emsp;&emsp;&emsp;keyTab                             | kerberos keytab                                              |        | false   | string              |                     |
| &emsp;&emsp;&emsp;&emsp;principal                          | kerberos principal                                           |        | false   | string              |                     |
| &emsp;&emsp;&emsp;&emsp;compressiontype                    | compression type of Kafka                                    |        | false   | string              |                     |
| &emsp;&emsp;&emsp;&emsp;clientId                           | client Id of MQTT or AWS IoT                                 |        | false   | string              |                     |
| &emsp;&emsp;&emsp;&emsp;qos                                | qos of MQTT or AWS IoT                                       |        | false   | integer(int32)      |                     |
| &emsp;&emsp;&emsp;&emsp;ssl                                | whether to enable SSL of MQTT                                |        | false   | boolean             |                     |
| &emsp;&emsp;&emsp;&emsp;certificatePemLocation             | certificate Location                                         |        | false   | string              |                     |
| &emsp;&emsp;&emsp;&emsp;privatePemKey                      | private key Location                                         |        | false   | string              |                     |
| &emsp;&emsp;&emsp;&emsp;caPemLocation                      | CA Location                                                  |        | false   | string              |                     |


**Status**:


| code | description          | schema |
| ---- | -------------------- | ------ |
| 200  | successful operation | Result |
| 400  | invalid parameters   | Result |


**code-200**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
	"success": true,
	"message": null,
	"data": null
}
```


**code-400**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
	"success": false,
	"message": "failed to modify options.",
	"data": null
}
```





## Driver Management

### protocol entity

**SiemensS7**

| name          | description                                                  | type           |
| ------------- | ------------------------------------------------------------ | -------------- |
| ipAddr        | IP of Siemens PLC                                            | string         |
| port          | Port of Siemens PLC                                          | integer(int32) |
| processorType | The currently supported Siemens PLC types, including S7-200, S7-200SMART, S7-300, S7-400, S7-1200 and S7-1500. | string         |

**Modbus**

| name             | description                                                  | type           |
| ---------------- | ------------------------------------------------------------ | -------------- |
| slaveId          | The MODBUS Slave ID is a unique identifier for a slave device in a MODBUS network. | integer(int32) |
| wordSwap         | Refers to the process of reordering multi-byte units (words) within a larger data structure. A word is typically 16 bits (2 bytes), 32 bits (4 bytes), or 64 bits (8 bytes). | boolean        |
| byteSwap         | Refers to the process of reversing the order of bytes within a multi-byte data unit. | boolean        |
| transmissionMode | Refers to the mode used for communication in MODBUS, including RTU (Remote Terminal Unit) , TCP(Transmission Control Protocol) and ASCII (American Standard Code for Information Interchange) modes. | string         |
| modeParams       | for TCP format is `{"ipAddr": "", "port":""}`, for RTU format  is `{"serialPort": "", "baudRate":"", "parity":"", "dataBits":"", "stopBits":""}` | object         |

**OpcDA**

| name       | description                                                  | type   |
| ---------- | ------------------------------------------------------------ | ------ |
| ipAddr     | IP of OPC DA Server                                          | string |
| domain     | The computer name of the machine where the OPC DA server is located. or it can be set to the IP address of the server computer. | string |
| serverName | OPC Program Name.                                            | string |
| username   | The username is the Windows user name with DCOM permissions. | string |
| password   | password                                                     | string |

**OpcUA**

| name                 | description                                                  | type   |
| -------------------- | ------------------------------------------------------------ | ------ |
| serverUrl            | OPC UA Server Endpoint Url, format is `opc.tcp://ipaddress:port/{servername}` | string |
| authenticationMethod | The authentication method supports anonymous and user account methods. | string |
| username             | username                                                     | string |
| password             | password                                                     | string |
| securityMode         | Refers to the security settings that define how messages are protected during communication. These modes include None, Sign, and SignAndEncrypt. | string |
| securityPolicy       | It defines the security encryption algorithms and settings used to protect communication, including None, Basic128Rsa15, Basic256, Basic256Sha256, Aes128_Sha256_RsaOaep and Aes256_Sha256_RsaPss. | string |

**CNC**

| name   | description          | type           |
| ------ | -------------------- | -------------- |
| ipAddr | IP of CNC            | string         |
| port   | Port of CNC          | integer(int32) |
| type   | machine type of CNC. | string         |


### add driver

**url**:`/api/v1/driver/{nodeId}`

**method**:`POST`

**produces**:`application/json`


**consumes**:`application/json`


**Note**:


**Example**:


```javascript
{
    "enable": true,
    "driverName": "driver_demo",
    "driverType": "Modbus",
    "protocol": {
        "slaveId": 1,
        "transmissionMode": "TCP",
        "wordSwap": true,
        "byteSwap": false,
        "modeParams": {
            "ipAddr": "192.168.1.16",
            "port": 54
        }
    }
}
```


**Params**:


| name                   | description                                                  | in     | require | type       | schema     |
| ---------------------- | ------------------------------------------------------------ | ------ | ------- | ---------- | ---------- |
| Authorization          | Bearer token for authentication, format is: `Bearer ${token}`                              | header | true    | string     |            |
| nodeId                 | node id                                                      | path   | true    | string     |            |
| driverInfo             | DriverInfo                                                   | body   | true    | DriverInfo | DriverInfo |
| &emsp;&emsp;driverName | driver name                                                  |        | true    | string     |            |
| &emsp;&emsp;enable     | whether it is enabled                                        |        | true    | boolean    |            |
| &emsp;&emsp;driverType | driver type, including Siemens S7, Modbus, OPC DA, OPC UA, and etc. |        | true    | string     |            |
| &emsp;&emsp;protocol   | protocol object                                              |        | true    | object     |            |


**Status**:


| code | description          | schema |
| ---- | -------------------- | ------ |
| 200  | successful operation | Result |
| 400  | invalid parameters   | Result |


**code-200**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
    "success":true,
    "message":null,
    "data":{"driverId":"ff890a36"}
}
```


**code-400**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
	"success": false,
	"message": "invalid parameters",
	"data": null
}
```


### edit driver


**url**:`/api/v1/driver/{nodeId}/{driverId}`


**method**:`PUT`

**produces**:`application/json`


**consumes**:`application/json`


**Note**:


**Example**:


```javascript
{
    "enable": true,
    "driverName": "driver_demo",
    "driverType": "Modbus",
    "protocol": {
        "slaveId": 1,
        "transmissionMode": "TCP",
        "wordSwap": true,
        "byteSwap": false,
        "modeParams": {
            "ipAddr": "192.168.1.16",
            "port": 504
        }
    }
}
```


**Params**:


| name                   | description                                                  | in     | require | type       | schema     |
| ---------------------- | ------------------------------------------------------------ | ------ | ------- | ---------- | ---------- |
| Authorization          | Bearer token for authentication, format is: `Bearer ${token}`                              | header | true    | string     |            |
| nodeId                 | node id                                                      | path   | true    | string     |            |
| driverId               | driver id                                                    | path   | true    | string     |            |
| driverInfo             | DriverInfo                                                   | body   | true    | DriverInfo | DriverInfo |
| &emsp;&emsp;driverName | driver name                                                  |        | true    | string     |            |
| &emsp;&emsp;enable     | whether it is enabled                                        |        | true    | boolean    |            |
| &emsp;&emsp;driverType | driver type, including Siemens S7, Modbus, OPC DA, OPC UA, and etc. |        | true    | string     |            |
| &emsp;&emsp;protocol   | protocol object                                              |        | true    | object     |            |


**Status**:


| code | description          | schema |
| ---- | -------------------- | ------ |
| 200  | successful operation | Result |
| 404  | driver not found     | Result |


**code-200**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
    "success":true,
    "message":null,
    "data":{"driverId":"ff890a36"}
}
```


**code-404**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
	"success": false,
	"message": "driver not found",
	"data": {}
}
```


### query drivers


**url**:`/api/v1/driver/{nodeId}`


**method**:`GET`

**produces**:`multipart/form-data`


**consumes**:`application/json`


**Note**:


**Params**:


| name          | description                     | in     | require | type           | schema |
| ------------- | ------------------------------- | ------ | ------- | -------------- | ------ |
| Authorization | Bearer token for authentication, format is: `Bearer ${token}` | header | true    | string         |        |
| nodeId        | node id                         | path   | true    | string         |        |
| pageNum       | current page number             | query  | false   | integer(int32) |        |
| pageSize      | page size                       | query  | false   | integer(int32) |        |
| driverName    | driver name                     | query  | false   | string         |        |
| driverType    | driver type                     | query  | false   | string         |        |


**Status**:


| code | description          | schema |
| ---- | -------------------- | ------ |
| 200  | successful operation | Result |
| 400  | invalid parameters   | Result |


**code-200**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
    "success": true,
    "message": null,
    "data": {
        "total": 17,
        "pageSize": 9,
        "rows": [
            {
                "driverId": "0cd5e37a",
                "driverName": "opcda",
                "enable": true,
                "driverType": "OPC DA",
                "protocol": {
                    "ipAddr": "192.168.101.205",
                    "domain": "192.168.101.205",
                    "serverName": "Matrikon.OPC.Simulation.1",
                    "username": "Administrator",
                    "password": "ppppppp"
                }
            },
            {
                "driverId": "27017bc9",
                "driverName": "modbus-53",
                "enable": true,
                "driverType": "Modbus",
                "protocol": {
                    "slaveId": 1,
                    "wordSwap": false,
                    "byteSwap": false,
                    "transmissionMode": "TCP",
                    "modeParams": {
                        "ipAddr": "192.168.101.152",
                        "port": 502
                    }
                }
            },
            {
                "driverId": "619ede13",
                "driverName": "driver-test01",
                "enable": true,
                "driverType": "Siemens S7",
                "protocol": {
                    "ipAddr": "192.168.1.12",
                    "port": 54,
                    "processorType": "S1200"
                }
            },
            {
                "driverId": "7af9651b",
                "driverName": "ua2",
                "enable": true,
                "driverType": "OPC UA",
                "protocol": {
                    "serverUrl": "opc.tcp://192.168.101.150:53530/inrevo",
                    "domain": null,
                    "authenticationMethod": "Anonymous",
                    "username": null,
                    "password": null,
                    "securityMode": "Sign",
                    "securityPolicy": "Basic256"
                }
            },
            {
                "driverId": "7ee782b5",
                "driverName": "s7-2",
                "enable": true,
                "driverType": "Siemens S7",
                "protocol": {
                    "ipAddr": "192.168.0.1",
                    "port": 102,
                    "processorType": "S1200"
                }
            },
            {
                "driverId": "8f8d7126",
                "driverName": "modbus-002",
                "enable": true,
                "driverType": "Modbus",
                "protocol": {
                    "slaveId": 1,
                    "wordSwap": false,
                    "byteSwap": false,
                    "transmissionMode": "RTU",
                    "modeParams": {
                        "serialPort": "COM3",
                        "baudRate": 9600,
                        "parity": "None",
                        "dataBits": "Bits 8",
                        "stopBits": "One"
                    }
                }
            },
            {
                "driverId": "909d9b12",
                "driverName": "fanuc2",
                "enable": true,
                "driverType": "CNC",
                "protocol": {
                    "ipAddr": "192.168.9.87",
                    "port": 65,
                    "type": "Fanuc"
                }
            },
            {
                "driverId": "94d37f04",
                "driverName": "ua",
                "enable": true,
                "driverType": "OPC UA",
                "protocol": {
                    "serverUrl": "opc.tcp://192.168.101.150:53530/inrevo",
                    "domain": null,
                    "authenticationMethod": "Anonymous",
                    "username": null,
                    "password": null,
                    "securityMode": "Sign",
                    "securityPolicy": "Basic256"
                }
            },
            {
                "driverId": "a11115c0",
                "driverName": "driver-test02",
                "enable": true,
                "driverType": "Siemens S7",
                "protocol": {
                    "ipAddr": "192.168.1.12",
                    "port": 54,
                    "processorType": "S1200"
                }
            }
        ],
        "pageNum": 1
    }
}
```


**code-400**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
	"success": false,
	"message": "invalid parameters",
	"data": {}
}
```



### delete driver


**url**:`/api/v1/driver/{nodeId}/{driverId}`


**method**:`DELETE`


**produces**:`application/x-www-form-urlencoded`


**consumes**:`application/json`


**Note**:


**Params**:


| name          | description                     | in     | require | type   | schema |
| ------------- | ------------------------------- | ------ | ------- | ------ | ------ |
| Authorization | Bearer token for authentication, format is: `Bearer ${token}` | header | true    | string |        |
| nodeId        | node id                         | path   | true    | string |        |
| driverId      | driver id                       | path   | true    | string |        |


**Status**:


| code | description          | schema |
| ---- | -------------------- | ------ |
| 200  | successful operation | Result |
| 404  | driver not found     | Result |


**code-200**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
	"success": true,
	"message": null,
	"data": null
}
```


**code-404**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
	"success": false,
	"message": "driver not found",
	"data": {}
}
```


### delete drivers


**url**:`/api/v1/driver/{nodeId}`


**method**:`DELETE`

**produces**:`application/json`


**consumes**:`application/json`

**Note**:


**Example**:


```javascript
["94d37f04", "909d9b12"]
```


**Params**:


| name          | description                                                  | in     | require | type   | schema |
| ------------- | ------------------------------------------------------------ | ------ | ------- | ------ | ------ |
| Authorization | Bearer token for authentication, format is: `Bearer ${token}` | header | true    | string |        |
| nodeId        | node id                                                      | path   | true    | string |        |
| driverIds     | driver ids                                                   | body   | true    | array  |        |


**Status**:


| code | description                       | schema |
| ---- | --------------------------------- | ------ |
| 200  | successful operation              | Result |
| 207  | some drivers failed to be deleted | Result |


**code-200**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
	"success": true,
	"message": null,
	"data": null
}
```

**code-207**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
	"success": false,
	"message": "deleting driver [909d9b12] failed",
	"data": { "failedIds": ["909d9b12"]}
}
```


### import drivers


**url**:`/api/v1/driver/import/{nodeId}`


**method**:`POST`

**produces**:`multipart/form-data`


**consumes**:`application/json`

**Note**:<p>create drivers by importing excel file</p>



**Params**:


| name          | description                     | in     | require | type   | schema |
| ------------- | ------------------------------- | ------ | ------- | ------ | ------ |
| Authorization | Bearer token for authentication, format is: `Bearer ${token}` | header | true    | string |        |
| nodeId        | node id                         | path   | true    | string |        |
| file          | excel file with driver info     | query  | true    | file   |        |


**Status**:


| code | description          | schema |
| ---- | -------------------- | ------ |
| 200  | successful operation | Result |
| 400  | invalid parameters   | Result |


**code-200**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
	"success": true,
	"message": null,
	"data": null
}
```


**code-400**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
	"success": false,
	"message": "failed to add drivers",
	"data": null
}
```


## Point Management



### add group

**url**:`/api/v1/point/group/{nodeId}`


**method**:`POST`

**produces**:`application/x-www-form-urlencoded, multipart/form-data`


**consumes**:`application/json`

**Note**:


**Params**:


| name          | description                     | in     | require | type   | schema |
| ------------- | ------------------------------- | ------ | ------- | ------ | ------ |
| Authorization | Bearer token for authentication, format is: `Bearer ${token}` | header | true    | string |        |
| nodeId        | node id                         | path   | true    | string |        |
| groupName     | group name                      | query  | true    | string |        |


**Status**:


| code | description          | schema |
| ---- | -------------------- | ------ |
| 200  | successful operation | Result |
| 400  | invalid parameters   | Result |


**code-200**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
    "success":true,
    "message":null,
    "data":{
        "groupId":"b9b01917"
    }
}
```


**code-400**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
	"success": false,
	"message": "failed to add group.",
	"data": {}
}
```



### edit group


**url**:`/api/v1/point/group/{nodeId}/{groupId}`

**method**:`PUT`

**produces**:`multipart/form-data`


**consumes**:`application/json`

**Note**:


**Params**:


| name          | description                     | in     | require | type   | schema |
| ------------- | ------------------------------- | ------ | ------- | ------ | ------ |
| Authorization | Bearer token for authentication, format is: `Bearer ${token}` | header | true    | string |        |
| nodeId        | node id                         | path   | true    | string |        |
| groupId       | group id                        | path   | true    | string |        |
| groupName     | group name                      | query  | true    | string |        |


**Status**:


| code | description          | schema |
| ---- | -------------------- | ------ |
| 200  | successful operation | Result |
| 400  |                      |        |
| 404  | group not found      | Result |


**code-200**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
    "success":true,
     "message":null,
      "data":{
          "groupId":"fe3dbfed"
      }
}
```


**code-404**:

**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
    "success":false,
    "message":"the group name already exists.",
     "data":null
}
```


### delete group


**url**:`/api/v1/point/group/{nodeId}/{groupId}`


**method**:`DELETE`


**produces**:`application/x-www-form-urlencoded`


**consumes**:`application/json`


**Note**:


**Params**:


| name          | description                     | in     | require | type   | schema |
| ------------- | ------------------------------- | ------ | ------- | ------ | ------ |
| Authorization | Bearer token for authentication, format is: `Bearer ${token}` | header | true    | string |        |
| nodeId        | node id                         | path   | true    | string |        |
| groupId       | group id                        | path   | true    | string |        |


**Status**:


| code | description          | schema |
| ---- | -------------------- | ------ |
| 200  | successful operation | Result |
| 404  | group not found      | Result |


**code-200**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
	"success": true,
	"message": null,
	"data": null
}
```


**code-404**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
	"success": false,
	"message": "group not found",
	"data": null
}
```


### delete groups


**url**:`/api/v1/point/group/{nodeId}`


**method**:`DELETE`

**produces**:`application/json`


**consumes**:`application/json`


**Note**:


**Example**:


```javascript
["2622469c", "a833ea51"]
```


**Params**:


| name          | description                                                  | in     | require | type   | schema |
| ------------- | ------------------------------------------------------------ | ------ | ------- | ------ | ------ |
| Authorization | Bearer token for authentication, format is: `Bearer ${token}` | header | true    | string |        |
| nodeId        | node id                                                      | path   | true    | string |        |
| groupIds      | group ids                                                    | body   | true    | array  |        |


**Status**:


| code | description                      | schema |
| ---- | -------------------------------- | ------ |
| 200  | successful operation             | Result |
| 207  | some groups failed to be deleted | Result |


**code-200**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
	"success": true,
	"message": null,
	"data": null
}
```


**code-207**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
	"success": false,
	"message": "deleting group [a833ea51] failed",
	"data": { "failedIds": ["a833ea51"]}
}
```


### query groups


**url**:`/api/v1/point/group/{nodeId}`


**method**:`GET`

**produces**:`multipart/form-data`


**consumes**:`application/json`


**Note**:


**Params**:


| name          | description                     | in     | require | type           | schema |
| ------------- | ------------------------------- | ------ | ------- | -------------- | ------ |
| Authorization | Bearer token for authentication, format is: `Bearer ${token}` | header | true    | string         |        |
| nodeId        | node id                         | path   | true    | string         |        |
| pageNum       | current page number             | query  | false   | integer(int32) |        |
| pageSize      | page size                       | query  | false   | integer(int32) |        |
| groupId       | point id                        | query  | false   | string         |        |
| groupName     | point name                      | query  | false   | string         |        |


**Status**:


| code | description          | schema |
| ---- | -------------------- | ------ |
| 200  | successful operation | Result |
| 400  | invalid parameters   | Result |


**code-200**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
    "success": true,
    "message": null,
    "data": {
        "total": 5,
        "pageSize": 5,
        "rows": [
            {
                "groupId": "0caa4e7b",
                "groupName": "group3"
            },
            {
                "groupId": "1b5ae2f3",
                "groupName": "group2"
            },
            {
                "groupId": "2622469c",
                "groupName": "group4"
            },
            {
                "groupId": "a833ea51",
                "groupName": "group1"
            },
            {
                "groupId": "fe3dbfed",
                "groupName": "demo7"
            }
        ],
        "pageNum": 1
    }
}
```


**code-400**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
	"success": false,
	"message": "invalid parameters",
	"data": null
}
```


### add point


**url**:`/api/v1/point/{nodeId}`


**method**:`POST`

**produces**:`application/json`


**consumes**:`application/json`


**Note**:


**Example**:


```javascript
{
  "pointName": "point_1",
  "enable": true,
  "groupId": "a833ea51",
  "driverId": "adbb1778",
  "address": "DB1.10",
  "dataType": "int32",
  "unit": "cm",
  "period": 5,
  "formula": null,
  "alarm": false,
  "alarmType": "",
  "alarmLevel": 0,
  "highHigh": null,
  "high": null,
  "low": null,
  "lowLow": null,
  "value": null
}
```


**Params**:


| name                   | description                                                  | in     | require | type           | schema    |
| ---------------------- | ------------------------------------------------------------ | ------ | ------- | -------------- | --------- |
| Authorization          | Bearer token for authentication, format is: `Bearer ${token}` | header | true    | string         |           |
| nodeId                 | node id                                                      | path   | true    | string         |           |
| pointInfo              | PointInfo                                                    | body   | true    | PointInfo      | PointInfo |
| &emsp;&emsp;pointName  | point name                                                   |        | true    | string         |           |
| &emsp;&emsp;enable     | whether it is enabled                                        |        | true    | boolean        |           |
| &emsp;&emsp;groupId    | group id                                                     |        | true    | string         |           |
| &emsp;&emsp;driverId   | driver id                                                    |        | true    | string         |           |
| &emsp;&emsp;address    | point address                                                |        | true    | string         |           |
| &emsp;&emsp;dataType   | data type                                                    |        | true    | string         |           |
| &emsp;&emsp;unit       | unit                                                         |        | true    | string         |           |
| &emsp;&emsp;period     | acquisition cycle, unit: second                              |        | true    | integer(int32) |           |
| &emsp;&emsp;formula    | formula                                                      |        | false   | string         |           |
| &emsp;&emsp;alarm      | whether to enable the alarm function                         |        | false   | boolean        |           |
| &emsp;&emsp;alarmType  | alarm type, including threshold and equal                    |        | false   | string         |           |
| &emsp;&emsp;alarmLevel | alarm level, including 1,2,3,4, and 5                        |        | false   | integer(int32) |           |
| &emsp;&emsp;highHigh   | high high vaule to judge                                     |        | false   | number(double) |           |
| &emsp;&emsp;high       | high vaule to judge                                          |        | false   | number(double) |           |
| &emsp;&emsp;low        | low vaule to judge                                           |        | false   | number(double) |           |
| &emsp;&emsp;lowLow     | low low vaule to judge                                       |        | false   | number(double) |           |
| &emsp;&emsp;value      | matched value to compare                                     |        | false   | string         |           |


**Status**:


| code | description          | schema |
| ---- | -------------------- | ------ |
| 200  | successful operation | Result |
| 400  | invalid parameters   | Result |


**code-200**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |

**Response Example**:

```javascript
{
    "success":true,
    "message":null,
    "data":{
        "pointId":"97c6254b"
    }
}
```


**code-400**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
	"success": false,
	"message": "failed to add point.",
	"data": {}
}
```


### edit point


**url**:`/api/v1/point/{nodeId}/{pointId}`


**method**:`PUT`

**produces**:`application/json`


**consumes**:`application/json`


**Note**:


**Example**:


```javascript
{
  "pointName": "point_1",
  "enable": true,
  "groupId": "a833ea51",
  "driverId": "adbb1778",
  "address": "DB1.10",
  "dataType": "int32",
  "unit": "cm",
  "period": 10,
  "formula": null,
  "alarm": false,
  "alarmType": "",
  "alarmLevel": 0,
  "highHigh": null,
  "high": null,
  "low": null,
  "lowLow": null,
  "value": null
}
```


**Params**:


| name                   | description                                                  | in     | require | type           | schema    |
| ---------------------- | ------------------------------------------------------------ | ------ | ------- | -------------- | --------- |
| Authorization          | Bearer token for authentication, format is: `Bearer ${token}` | header | true    | string         |           |
| nodeId                 | node id                                                      | path   | true    | string         |           |
| pointId                | point id                                                     | path   | true    | string         |           |
| pointInfo              | PointInfo                                                    | body   | true    | PointInfo      | PointInfo |
| &emsp;&emsp;pointName  | point name                                                   |        | true    | string         |           |
| &emsp;&emsp;enable     | whether it is enabled                                        |        | true    | boolean        |           |
| &emsp;&emsp;groupId    | group id                                                     |        | true    | string         |           |
| &emsp;&emsp;driverId   | driver id                                                    |        | true    | string         |           |
| &emsp;&emsp;address    | point address                                                |        | true    | string         |           |
| &emsp;&emsp;dataType   | data type                                                    |        | true    | string         |           |
| &emsp;&emsp;unit       | unit                                                         |        | true    | string         |           |
| &emsp;&emsp;period     | acquisition cycle, unit: second                              |        | true    | integer(int32) |           |
| &emsp;&emsp;formula    | formula                                                      |        | false   | string         |           |
| &emsp;&emsp;alarm      | whether to enable the alarm function                         |        | false   | boolean        |           |
| &emsp;&emsp;alarmType  | alarm type, including threshold and equal                    |        | false   | string         |           |
| &emsp;&emsp;alarmLevel | alarm level, including 1,2,3,4, and 5                        |        | false   | integer(int32) |           |
| &emsp;&emsp;highHigh   | high high vaule to judge                                     |        | false   | number(double) |           |
| &emsp;&emsp;high       | high vaule to judge                                          |        | false   | number(double) |           |
| &emsp;&emsp;low        | low vaule to judge                                           |        | false   | number(double) |           |
| &emsp;&emsp;lowLow     | low low vaule to judge                                       |        | false   | number(double) |           |
| &emsp;&emsp;value      | matched value to compare                                     |        | false   | string         |           |


**Status**:


| code | description          | schema |
| ---- | -------------------- | ------ |
| 200  | successful operation | Result |
| 404  | point not found      | Result |


**code-200**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
    "success":true,
    "message":null,
    "data":{
        "pointId":"97c6254b"
    }
}
```


**code-404**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
	"success": false,
	"message": "point not found",
	"data": {}
}
```

### query points


**url**:`/api/v1/point/{nodeId}`


**method**:`GET`

**produces**:`multipart/form-data`


**consumes**:`application/json`


**Note**:


**Params**:


| name          | description                     | in     | require | type           | schema |
| ------------- | ------------------------------- | ------ | ------- | -------------- | ------ |
| Authorization | Bearer token for authentication, format is: `Bearer ${token}` | header | true    | string         |        |
| nodeId        | node id                         | path   | true    | string         |        |
| pageNum       | current page number             | query  | false   | integer(int32) |        |
| pageSize      | page size                       | query  | false   | integer(int32) |        |
| pointId       | point id                        | query  | false   | string         |        |
| pointName     | point name                      | query  | false   | string         |        |
| groupName     | group name                      | query  | false   | string         |        |
| driverName    | driver name                     | query  | false   | string         |        |


**Status**:


| code | description          | schema |
| ---- | -------------------- | ------ |
| 200  | successful operation | Result |
| 400  | invalid parameters   | Result |


**code-200**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
    "success": true,
    "message": null,
    "data": {
        "total": 6000,
        "pageSize": 10,
        "rows": [
            {
                "pointId": "1000000",
                "pointName": "test0001",
                "enable": true,
                "groupId": "0caa4e7b",
                "groupName": "group3",
                "driverId": "f8753fc5",
                "driverName": "Fanuc01",
                "address": "1000",
                "dataType": "float64",
                "unit": "m",
                "peroid": 2,
                "formula": null,
                "alarm": true,
                "alarmType": "Equal",
                "alarmLevel": 1,
                "highHigh": null,
                "high": null,
                "low": null,
                "lowLow": null,
                "value": "1.2",
                "flag": null
            },
            {
                "pointId": "1000001",
                "pointName": "test0002",
                "enable": true,
                "groupId": "0caa4e7b",
                "groupName": "group3",
                "driverId": "f8753fc5",
                "driverName": "Fanuc01",
                "address": "1001",
                "dataType": "float64",
                "unit": "m",
                "peroid": 2,
                "formula": null,
                "alarm": true,
                "alarmType": "Equal",
                "alarmLevel": 1,
                "highHigh": null,
                "high": null,
                "low": null,
                "lowLow": null,
                "value": "1.2",
                "flag": null
            },
            {
                "pointId": "1000002",
                "pointName": "test0003",
                "enable": true,
                "groupId": "0caa4e7b",
                "groupName": "group3",
                "driverId": "f8753fc5",
                "driverName": "Fanuc01",
                "address": "1002",
                "dataType": "float64",
                "unit": "m",
                "peroid": 2,
                "formula": null,
                "alarm": true,
                "alarmType": "Equal",
                "alarmLevel": 1,
                "highHigh": null,
                "high": null,
                "low": null,
                "lowLow": null,
                "value": "1.2",
                "flag": null
            },
            {
                "pointId": "1000003",
                "pointName": "test0004",
                "enable": true,
                "groupId": "0caa4e7b",
                "groupName": "group3",
                "driverId": "f8753fc5",
                "driverName": "Fanuc01",
                "address": "1003",
                "dataType": "float64",
                "unit": "m",
                "peroid": 2,
                "formula": null,
                "alarm": true,
                "alarmType": "Equal",
                "alarmLevel": 1,
                "highHigh": null,
                "high": null,
                "low": null,
                "lowLow": null,
                "value": "1.2",
                "flag": null
            },
            {
                "pointId": "1000004",
                "pointName": "test0005",
                "enable": true,
                "groupId": "0caa4e7b",
                "groupName": "group3",
                "driverId": "f8753fc5",
                "driverName": "Fanuc01",
                "address": "1004",
                "dataType": "float64",
                "unit": "m",
                "peroid": 2,
                "formula": null,
                "alarm": true,
                "alarmType": "Equal",
                "alarmLevel": 1,
                "highHigh": null,
                "high": null,
                "low": null,
                "lowLow": null,
                "value": "1.2",
                "flag": null
            },
            {
                "pointId": "1000005",
                "pointName": "test0006",
                "enable": true,
                "groupId": "0caa4e7b",
                "groupName": "group3",
                "driverId": "f8753fc5",
                "driverName": "Fanuc01",
                "address": "1005",
                "dataType": "float64",
                "unit": "m",
                "peroid": 2,
                "formula": null,
                "alarm": true,
                "alarmType": "Equal",
                "alarmLevel": 1,
                "highHigh": null,
                "high": null,
                "low": null,
                "lowLow": null,
                "value": "1.2",
                "flag": null
            },
            {
                "pointId": "1000006",
                "pointName": "test0007",
                "enable": true,
                "groupId": "0caa4e7b",
                "groupName": "group3",
                "driverId": "f8753fc5",
                "driverName": "Fanuc01",
                "address": "1006",
                "dataType": "float64",
                "unit": "m",
                "peroid": 2,
                "formula": null,
                "alarm": true,
                "alarmType": "Equal",
                "alarmLevel": 1,
                "highHigh": null,
                "high": null,
                "low": null,
                "lowLow": null,
                "value": "1.2",
                "flag": null
            },
            {
                "pointId": "1000007",
                "pointName": "test0008",
                "enable": true,
                "groupId": "0caa4e7b",
                "groupName": "group3",
                "driverId": "f8753fc5",
                "driverName": "Fanuc01",
                "address": "1007",
                "dataType": "float64",
                "unit": "m",
                "peroid": 2,
                "formula": null,
                "alarm": true,
                "alarmType": "Equal",
                "alarmLevel": 1,
                "highHigh": null,
                "high": null,
                "low": null,
                "lowLow": null,
                "value": "1.2",
                "flag": null
            },
            {
                "pointId": "1000008",
                "pointName": "test0009",
                "enable": true,
                "groupId": "0caa4e7b",
                "groupName": "group3",
                "driverId": "f8753fc5",
                "driverName": "Fanuc01",
                "address": "1008",
                "dataType": "float64",
                "unit": "m",
                "peroid": 2,
                "formula": null,
                "alarm": true,
                "alarmType": "Equal",
                "alarmLevel": 1,
                "highHigh": null,
                "high": null,
                "low": null,
                "lowLow": null,
                "value": "1.2",
                "flag": null
            },
            {
                "pointId": "1000009",
                "pointName": "test0010",
                "enable": true,
                "groupId": "0caa4e7b",
                "groupName": "group3",
                "driverId": "f8753fc5",
                "driverName": "Fanuc01",
                "address": "1009",
                "dataType": "float64",
                "unit": "m",
                "peroid": 2,
                "formula": null,
                "alarm": true,
                "alarmType": "Equal",
                "alarmLevel": 1,
                "highHigh": null,
                "high": null,
                "low": null,
                "lowLow": null,
                "value": "1.2",
                "flag": null
            }
        ],
        "pageNum": 1
    }
}
```


**code-400**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
	"success": false,
	"message": "invalid parameters",
	"data": {}
}
```


### delete point


**url**:`/api/v1/point/{nodeId}/{pointId}`


**method**:`DELETE`


**produces**:`application/x-www-form-urlencoded`


**consumes**:`application/json`


**Note**:


**Params**:


| name          | description                     | in     | require | type   | schema |
| ------------- | ------------------------------- | ------ | ------- | ------ | ------ |
| Authorization | Bearer token for authentication, format is: `Bearer ${token}` | header | true    | string |        |
| nodeId        | node id                         | path   | true    | string |        |
| pointId       | point id                        | path   | true    | string |        |


**Status**:


| code | description          | schema |
| ---- | -------------------- | ------ |
| 200  | successful operation | Result |
| 404  | point not found      | Result |


**code-200**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
	"success": true,
	"message": null,
	"data": null
}
```


**code-404**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
	"success": false,
	"message": "point not found",
	"data": {}
}
```

### delete points


**url**:`/api/v1/point/{nodeId}`


**method**:`DELETE`

**produces**:`application/json`


**consumes**:`application/json`


**Note**:


**Example**:


```javascript
["1005999", "1005998"]
```


**Params**:


| name          | description                                                  | in     | require | type   | schema |
| ------------- | ------------------------------------------------------------ | ------ | ------- | ------ | ------ |
| Authorization | Bearer token for authentication, format is: `Bearer ${token}` | header | true    | string |        |
| nodeId        | node id                                                      | path   | true    | string |        |
| pointIds      | point ids                                                    | body   | true    | array  |        |


**Status**:


| code | description                      | schema |
| ---- | -------------------------------- | ------ |
| 200  | successful operation             | Result |
| 207  | some points failed to be deleted | Result |


**code-200**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
	"success": true,
	"message": null,
	"data": null
}
```


**code-207**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
	"success": false,
	"message": "deleting point [1005998] failed",
	"data": { "failedIds": ["1005998"]}
}
```


### import points


**url**:`/api/v1/point/import/{nodeId}`


**method**:`POST`

**produces**:`multipart/form-data`


**consumes**:`application/json`


**Note**:<p>create points by importing excel file</p>



**Params**:


| name          | description                     | in     | require | type   | schema |
| ------------- | ------------------------------- | ------ | ------- | ------ | ------ |
| Authorization | Bearer token for authentication, format is: `Bearer ${token}` | header | true    | string |        |
| nodeId        | node id                         | path   | true    | string |        |
| file          | excel file with point info      | query  | true    | file   |        |


**Status**:


| code | description          | schema |
| ---- | -------------------- | ------ |
| 200  | successful operation | Result |
| 400  | invalid parameters   | Result |


**code-200**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
	"success": true,
	"message": null,
	"data": null
}
```


**code-400**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
	"success": false,
	"message": "failed to add points",
	"data": null
}
```



## Data Management



### query data

**url**:`/api/v1/data/query/{nodeId}/{pointId}`

**method**:`GET`


**produces**:`application/x-www-form-urlencoded`


**consumes**:`application/json`


**Note**:<p>query real time data of point from database</p>



**Params**:


| name          | description                     | in     | require | type   | schema |
| ------------- | ------------------------------- | ------ | ------- | ------ | ------ |
| Authorization | Bearer token for authentication, format is: `Bearer ${token}` | header | true    | string |        |
| nodeId        | node id                         | path   | true    | string |        |
| pointId       | point id                        | path   | true    | string |        |


**Status**:


| code | description          | schema |
| ---- | -------------------- | ------ |
| 200  | successful operation | Result |
| 400  | invalid parameters   | Result |


**code-200**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
	"success": true,
	"message": "",
	"data": {
                "pointId": "1000000",
                "pointName": "test0001",
                "enable": true,
                "groupId": "0caa4e7b",
                "groupName": "group3",
                "driverId": "f8753fc5",
                "driverName": "Fanuc01",
                "address": "1000",
                "dataType": "float64",
                "unit": "m",
                "peroid": 2,
                "formula": null,
                "alarm": true,
                "alarmType": "Equal",
                "alarmLevel": 1,
                "highHigh": null,
                "high": null,
                "low": null,
                "lowLow": null,
                "value": "1.2",
                "flag": null
            }
}
```


**code-400**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
	"success": false,
	"message": "not found.",
	"data": null
}
```



### query data by point attribute


**url**:`/api/v1/data/query/{nodeId}`


**method**:`GET`

**produces**:`multipart/form-data`


**consumes**:`application/json`


**Note**:<p>query real time data by point attribute from database</p>



**Params**:


| name          | description                     | in     | require | type           | schema |
| ------------- | ------------------------------- | ------ | ------- | -------------- | ------ |
| Authorization | Bearer token for authentication, format is: `Bearer ${token}` | header | true    | string         |        |
| nodeId        | node id                         | path   | true    | string         |        |
| pageNum       | current page number             | query  | false   | integer(int32) |        |
| pageSize      | page size                       | query  | false   | integer(int32) |        |
| pointId       | point id                        | query  | false   | string         |        |
| pointName     | point name                      | query  | false   | string         |        |
| groupName     | group name                      | query  | false   | string         |        |


**Status**:


| code | description          | schema |
| ---- | -------------------- | ------ |
| 200  | successful operation | Result |
| 400  | invalid parameters   | Result |


**code-200**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
    "success": true,
    "message": null,
    "data": {
        "total": 30,
        "pageSize": 10,
        "rows": [
            {
                "pointId": "1000000",
                "pointName": "test0001",
                "enable": true,
                "groupId": "0caa4e7b",
                "groupName": "group3",
                "driverId": "f8753fc5",
                "driverName": "Fanuc01",
                "address": "1000",
                "dataType": "float64",
                "unit": "m",
                "peroid": 2,
                "formula": null,
                "alarm": true,
                "alarmType": "Equal",
                "alarmLevel": 1,
                "highHigh": null,
                "high": null,
                "low": null,
                "lowLow": null,
                "value": "1.2",
                "flag": null
            },
            {
                "pointId": "1000001",
                "pointName": "test0002",
                "enable": true,
                "groupId": "0caa4e7b",
                "groupName": "group3",
                "driverId": "f8753fc5",
                "driverName": "Fanuc01",
                "address": "1001",
                "dataType": "float64",
                "unit": "m",
                "peroid": 2,
                "formula": null,
                "alarm": true,
                "alarmType": "Equal",
                "alarmLevel": 1,
                "highHigh": null,
                "high": null,
                "low": null,
                "lowLow": null,
                "value": "1.2",
                "flag": null
            },
            {
                "pointId": "1000002",
                "pointName": "test0003",
                "enable": true,
                "groupId": "0caa4e7b",
                "groupName": "group3",
                "driverId": "f8753fc5",
                "driverName": "Fanuc01",
                "address": "1002",
                "dataType": "float64",
                "unit": "m",
                "peroid": 2,
                "formula": null,
                "alarm": true,
                "alarmType": "Equal",
                "alarmLevel": 1,
                "highHigh": null,
                "high": null,
                "low": null,
                "lowLow": null,
                "value": "1.2",
                "flag": null
            },
            {
                "pointId": "1000003",
                "pointName": "test0004",
                "enable": true,
                "groupId": "0caa4e7b",
                "groupName": "group3",
                "driverId": "f8753fc5",
                "driverName": "Fanuc01",
                "address": "1003",
                "dataType": "float64",
                "unit": "m",
                "peroid": 2,
                "formula": null,
                "alarm": true,
                "alarmType": "Equal",
                "alarmLevel": 1,
                "highHigh": null,
                "high": null,
                "low": null,
                "lowLow": null,
                "value": "1.2",
                "flag": null
            },
            {
                "pointId": "1000004",
                "pointName": "test0005",
                "enable": true,
                "groupId": "0caa4e7b",
                "groupName": "group3",
                "driverId": "f8753fc5",
                "driverName": "Fanuc01",
                "address": "1004",
                "dataType": "float64",
                "unit": "m",
                "peroid": 2,
                "formula": null,
                "alarm": true,
                "alarmType": "Equal",
                "alarmLevel": 1,
                "highHigh": null,
                "high": null,
                "low": null,
                "lowLow": null,
                "value": "1.2",
                "flag": null
            },
            {
                "pointId": "1000005",
                "pointName": "test0006",
                "enable": true,
                "groupId": "0caa4e7b",
                "groupName": "group3",
                "driverId": "f8753fc5",
                "driverName": "Fanuc01",
                "address": "1005",
                "dataType": "float64",
                "unit": "m",
                "peroid": 2,
                "formula": null,
                "alarm": true,
                "alarmType": "Equal",
                "alarmLevel": 1,
                "highHigh": null,
                "high": null,
                "low": null,
                "lowLow": null,
                "value": "1.2",
                "flag": null
            },
            {
                "pointId": "1000006",
                "pointName": "test0007",
                "enable": true,
                "groupId": "0caa4e7b",
                "groupName": "group3",
                "driverId": "f8753fc5",
                "driverName": "Fanuc01",
                "address": "1006",
                "dataType": "float64",
                "unit": "m",
                "peroid": 2,
                "formula": null,
                "alarm": true,
                "alarmType": "Equal",
                "alarmLevel": 1,
                "highHigh": null,
                "high": null,
                "low": null,
                "lowLow": null,
                "value": "1.2",
                "flag": null
            },
            {
                "pointId": "1000007",
                "pointName": "test0008",
                "enable": true,
                "groupId": "0caa4e7b",
                "groupName": "group3",
                "driverId": "f8753fc5",
                "driverName": "Fanuc01",
                "address": "1007",
                "dataType": "float64",
                "unit": "m",
                "peroid": 2,
                "formula": null,
                "alarm": true,
                "alarmType": "Equal",
                "alarmLevel": 1,
                "highHigh": null,
                "high": null,
                "low": null,
                "lowLow": null,
                "value": "1.2",
                "flag": null
            },
            {
                "pointId": "1000008",
                "pointName": "test0009",
                "enable": true,
                "groupId": "0caa4e7b",
                "groupName": "group3",
                "driverId": "f8753fc5",
                "driverName": "Fanuc01",
                "address": "1008",
                "dataType": "float64",
                "unit": "m",
                "peroid": 2,
                "formula": null,
                "alarm": true,
                "alarmType": "Equal",
                "alarmLevel": 1,
                "highHigh": null,
                "high": null,
                "low": null,
                "lowLow": null,
                "value": "1.2",
                "flag": null
            },
            {
                "pointId": "1000009",
                "pointName": "test0010",
                "enable": true,
                "groupId": "0caa4e7b",
                "groupName": "group3",
                "driverId": "f8753fc5",
                "driverName": "Fanuc01",
                "address": "1009",
                "dataType": "float64",
                "unit": "m",
                "peroid": 2,
                "formula": null,
                "alarm": true,
                "alarmType": "Equal",
                "alarmLevel": 1,
                "highHigh": null,
                "high": null,
                "low": null,
                "lowLow": null,
                "value": "1.2",
                "flag": null
            }
        ],
        "pageNum": 1
    }
}
```


**code-400**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
	"success": false,
	"message": "invalid parameters",
	"data": null
}
```



### query history data

**url**:`/api/v1/data/query/history/{nodeId}/{pointId}`


**method**:`GET`

**produces**:`multipart/form-data`


**consumes**:`application/json`

**Note**:<p>query history data of point from database </p>

<p>Before using this interface, ensure that the historical data storage function has been enabled.</p>



**Params**:


| name          | description                     | in     | require | type           | schema |
| ------------- | ------------------------------- | ------ | ------- | -------------- | ------ |
| Authorization | Bearer token for authentication, format is: `Bearer ${token}` | header | true    | string         |        |
| nodeId        | node id                         | path   | true    | string         |        |
| pointId       | point id                        | path   | true    | string         |        |
| startTime     | start time of historical data   | query  | true    | integer(int64) |        |
| endTime       | end time of historical data     | query  | true    | integer(int64) |        |
| pageNum       | current page number             | query  | false   | integer(int32) |        |
| pageSize      | page size                       | query  | false   | integer(int32) |        |


**Status**:


| code | description          | schema |
| ---- | -------------------- | ------ |
| 200  | successful operation | Result |
| 400  | invalid parameters   | Result |


**code-200**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
    "success": true,
    "message": null,
    "data": {
        "total": 3,
        "pageSize": 3,
        "rows": [
            {
                "nodeId": "e0333fd5",
                "pointId": "1000010",
                "driverId": null,
                "value": "0.09579200310053626",
                "dataType": "float64",
                "quality": "192",
                "timestamp": "2024-12-05 10:30:16.365",
                "pointName": "test0011",
                "groupName": "group3",
                "unit": "m",
                "isAlarm": false,
                "alarmType": null,
                "alarmLevel": null,
                "alarmMessage": null
            },
            {
                "nodeId": "e0333fd5",
                "pointId": "1000010",
                "driverId": null,
                "value": "0.7989260032129427",
                "dataType": "float64",
                "quality": "192",
                "timestamp": "2024-12-05 10:30:21.374",
                "pointName": "test0011",
                "groupName": "group3",
                "unit": "m",
                "isAlarm": false,
                "alarmType": null,
                "alarmLevel": null,
                "alarmMessage": null
            },
            {
                "nodeId": "e0333fd5",
                "pointId": "1000010",
                "driverId": null,
                "value": "0.3598228972773416",
                "dataType": "float64",
                "quality": "192",
                "timestamp": "2024-12-05 10:30:26.395",
                "pointName": "test0011",
                "groupName": "group3",
                "unit": "m",
                "isAlarm": false,
                "alarmType": null,
                "alarmLevel": null,
                "alarmMessage": null
            }
        ],
        "pageNum": 1
    }
}
```

**code-400**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
	"success": false,
	"message": "invalid parameters",
	"data": {}
}
```



### query history data of points


**url**:`/api/v1/data/query/history/{nodeId}`


**method**:`GET`

**produces**:`multipart/form-data`


**consumes**:`application/json`

**Note**:<p>query history data of points from database</p>

Before using this interface, ensure that the historical data storage function has been enabled.



**Params**:


| name          | description                     | in     | require | type           | schema |
| ------------- | ------------------------------- | ------ | ------- | -------------- | ------ |
| Authorization | Bearer token for authentication, format is: `Bearer ${token}` | header | true    | string         |        |
| nodeId        | node id                         | path   | true    | string         |        |
| pointIds      | point ids                       | query  | true    | array          | string |
| startTime     | start time of historical data   | query  | true    | integer(int64) |        |
| endTime       | end time of historical data     | query  | true    | integer(int64) |        |
| pageNum       | current page number             | query  | false   | integer(int32) |        |
| pageSize      | page size                       | query  | false   | integer(int32) |        |


**Status**:


| code | description          | schema |
| ---- | -------------------- | ------ |
| 200  | successful operation | Result |
| 400  | invalid parameters   | Result |


**code-200**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
    "success": true,
    "message": null,
    "data": {
        "total": 6,
        "pageSize": 6,
        "rows": [
            {
                "nodeId": "e0333fd5",
                "pointId": "1000011",
                "driverId": null,
                "value": "0.8813569641202135",
                "dataType": "float64",
                "quality": "192",
                "timestamp": "2024-12-05 10:30:16.365",
                "pointName": "test0012",
                "groupName": "group3",
                "unit": "m",
                "isAlarm": false,
                "alarmType": null,
                "alarmLevel": null,
                "alarmMessage": null
            },
            {
                "nodeId": "e0333fd5",
                "pointId": "1000010",
                "driverId": null,
                "value": "0.09579200310053626",
                "dataType": "float64",
                "quality": "192",
                "timestamp": "2024-12-05 10:30:16.365",
                "pointName": "test0011",
                "groupName": "group3",
                "unit": "m",
                "isAlarm": false,
                "alarmType": null,
                "alarmLevel": null,
                "alarmMessage": null
            },
            {
                "nodeId": "e0333fd5",
                "pointId": "1000010",
                "driverId": null,
                "value": "0.7989260032129427",
                "dataType": "float64",
                "quality": "192",
                "timestamp": "2024-12-05 10:30:21.374",
                "pointName": "test0011",
                "groupName": "group3",
                "unit": "m",
                "isAlarm": false,
                "alarmType": null,
                "alarmLevel": null,
                "alarmMessage": null
            },
            {
                "nodeId": "e0333fd5",
                "pointId": "1000011",
                "driverId": null,
                "value": "0.7606105185183109",
                "dataType": "float64",
                "quality": "192",
                "timestamp": "2024-12-05 10:30:21.374",
                "pointName": "test0012",
                "groupName": "group3",
                "unit": "m",
                "isAlarm": false,
                "alarmType": null,
                "alarmLevel": null,
                "alarmMessage": null
            },
            {
                "nodeId": "e0333fd5",
                "pointId": "1000010",
                "driverId": null,
                "value": "0.3598228972773416",
                "dataType": "float64",
                "quality": "192",
                "timestamp": "2024-12-05 10:30:26.395",
                "pointName": "test0011",
                "groupName": "group3",
                "unit": "m",
                "isAlarm": false,
                "alarmType": null,
                "alarmLevel": null,
                "alarmMessage": null
            },
            {
                "nodeId": "e0333fd5",
                "pointId": "1000011",
                "driverId": null,
                "value": "0.26630981170192236",
                "dataType": "float64",
                "quality": "192",
                "timestamp": "2024-12-05 10:30:26.395",
                "pointName": "test0012",
                "groupName": "group3",
                "unit": "m",
                "isAlarm": false,
                "alarmType": null,
                "alarmLevel": null,
                "alarmMessage": null
            }
        ],
        "pageNum": 1
    }
}
```


**code-400**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
	"success": false,
	"message": "invalid parameters",
	"data": null
}
```


### query alarm data

**url**:`/api/v1/alarm/query/{nodeId}`


**method**:`GET`

**produces**:`multipart/form-data`


**consumes**:`application/json`


**Note**:<p>query alarm data by point attribute from database</p>



**Params**:


| name          | description                     | in     | require | type           | schema |
| ------------- | ------------------------------- | ------ | ------- | -------------- | ------ |
| Authorization | Bearer token for authentication, format is: `Bearer ${token}` | header | true    | string         |        |
| nodeId        | node id                         | path   | true    | string         |        |
| startTime     | start time of historical data   | query  | true    | integer(int64) |        |
| endTime       | end time of historical data     | query  | true    | integer(int64) |        |
| pageNum       | current page number             | query  | false   | integer(int32) |        |
| pageSize      | page size                       | query  | false   | integer(int32) |        |
| pointId       | point id                        | query  | false   | string         |        |
| pointName     | point name                      | query  | false   | string         |        |
| groupName     | group name                      | query  | false   | string         |        |
| alarmType     | alarm type                      | query  | false   | string         |        |
| level         | alarm level                     | query  | false   | integer(int32) |        |
| isActive      | is alarmed                      | query  | false   | boolean        |        |


**Status**:


| code | description          | schema |
| ---- | -------------------- | ------ |
| 200  | successful operation | Result |
| 400  | invalid parameters   | Result |


**code-200**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
    "success": true,
    "message": null,
    "data": {
     "total":15,
     "pageNum": 0
     "pageSize": 3
     "rows":
    [
      {"nodeId":"2101", "alarmId":"101", pointId":"201", "pointName":"temp_1", "groupName":"group_1",  "startTime":"2024-06-28 10:20:00.132", "endTime":null, "value":"23", "alarmType":"threshold-high", "alarmMsg":"high than High(20) value", "level":1, "status":true},
      {"nodeId":"2101", "alarmId":"102", pointId":"202", "pointName":"temp_2", "groupName":"group_1",  "startTime":"2024-06-28 10:20:00.132", "endTime":"2024-06-29 10:25:00.132", "value":"23", "alarmType":"threshold-high", "alarmMsg":"high than High(20) value", "level":1, "status":false},
      {"nodeId":"2101", "alarmId":"103", pointId":"203", "pointName":"temp_3", "groupName":"group_1",  "startTime":"2024-06-29 10:20:00.132", "endTime":null, "value":"-3", "alarmType":"threshold-lowlow", "alarmMsg":"low than LowLow(-2) value", "level":1, "status":true}
    ]
  }
}
```


**code-400**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
	"success": false,
	"message": "invalid parameters",
	"data": null
}
```


### read data


**url**:`/api/v1/data/{nodeId}/{driverId}`

**method**:`GET`

**produces**:`multipart/form-data`


**consumes**:`application/json`


**Note**:<p>read point data from device directly</p>



**Params**:


| name          | description                     | in     | require | type   | schema |
| ------------- | ------------------------------- | ------ | ------- | ------ | ------ |
| Authorization | Bearer token for authentication, format is: `Bearer ${token}` | header | true    | string |        |
| nodeId        | node id                         | path   | true    | string |        |
| driverId      | driver id                       | path   | true    | string |        |
| pointIds      | point ids                       | query  | true    | array  | string |


**Status**:


| code | description          | schema |
| ---- | -------------------- | ------ |
| 200  | successful operation | Result |
| 400  | invalid parameters   | Result |


**code-200**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
    "success": true,
    "message": null,
    "data": [
       {"pointId": "1fdba65e", "pointName": "temp_1", "value": "23", "quality":"0", "timestamp":"2024-06-28 10:20:03" },
       {"pointId": "924f95c9", "pointName": "temp_2", "value": "23", "quality":"0", "timestamp":"2024-06-28 10:20:03" }
    ]
}
```


**code-400**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
	"success": false,
	"message": "invalid parameters",
	"data": null
}
```


### write data


**url**:`/api/v1/data/{nodeId}/{driverId}`


**method**:`POST`

**produces**:`application/json`


**consumes**:`application/json`


**Note**:<p>write data of points to device</p>



**Example**:


```javascript
[
{"pointId":"1fdba65e", "value":23},
{"pointId":"924f95c9", "value":29}
]
```


**Params**:


| name                | description                     | in     | require | type   | schema   |
| ------------------- | ------------------------------- | ------ | ------- | ------ | -------- |
| Authorization       | Bearer token for authentication, format is: `Bearer ${token}` | header | true    | string |          |
| nodeId              | node id                         | path   | true    | string |          |
| driverId            | driver id                       | path   | true    | string |          |
| valueSets           | ValueSet                        | body   | true    | array  | ValueSet |
| &emsp;&emsp;pointId | point id                        |        | true    | string |          |
| &emsp;&emsp;value   | point value                     |        | true    | object |          |


**Status**:


| code | description                       | schema |
| ---- | --------------------------------- | ------ |
| 200  | successful operation              | Result |
| 207  | some pointIds failed to be wroten |        |

**code-200**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
    "success": true,
    "message": null,
    "data": null
}
```

**code-207**:


**Response Params**:


| name    | description                     | type    | schema |
| ------- | ------------------------------- | ------- | ------ |
| success | whether it is successful or not | boolean |        |
| message | error message                   | string  |        |
| data    | content object                  | object  |        |


**Response Example**:
```javascript
{
    "success": false,
    "message": "some ids handle failed",
    "data": { "failedIds": ["924f95c9"]}
}
```


